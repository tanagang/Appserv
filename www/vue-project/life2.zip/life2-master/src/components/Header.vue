<template>
  <div name="header" class="header">
    <a href="javascript:void(0)" class="back" @click="goBack" v-show="isShow">
      <img src="static/img/2x/main_back@2x.png" />
    </a>
    {{msg}}
  </div>
</template>
<script>
export default {
  name: 'header',
  props:{
    'msg':String,
    'isShow':{
      type:Boolean,
      default: true
    }
  },
  methods:{
    goBack:function(){
      this.$router.go(-1)
    }
  }
}
</script>

<style>
  .header{height:45px;line-height: 45px;background: #3096FB;text-align: center;font-size:18px;color:#fff;position: relative;}
  .header .back{display:block;width:45px;height:45px;text-align: center;line-height: 45px;position: absolute;left:0;top:0;}
  .header .back:active{background:rgba(0,0,0,0.1);}
  .header .back img{width:10px;height:18px;}
</style>
