<template>
  <div name="setAdvise">
    <v-header msg="联系我们"></v-header>
    <div class="box direction-column">
      <textarea placeholder="请输入您的宝贵意见..." class="flex1"></textarea>
      <p>100</p>
    </div>
    <div class="m15">
       <mt-button type="primary" class="btn">提交</mt-button>
    </div>
  </div>
</template>

<script>
import VHeader from './Header'
export default {
  name: 'setAdvise',
  components:{VHeader},
  data () {
    return {

    }
  }
}
</script>

<style scoped>
  .box{border:1px solid #dbdbdb;margin:15px 13px;height:150px;}
  .box textarea{resize:none;padding:10px;border:none;}
  .box>p{text-align: right;padding:5px 10px;color:#999;font-size:16px;}
  .m15{margin-top:30px;}
  .m15 .btn{width:100%;}
</style>
