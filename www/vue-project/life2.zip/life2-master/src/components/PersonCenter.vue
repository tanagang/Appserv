<template>
  <div name="personCenter">
    <div class="header-bg box align-items-center justify-content-center">
      <div>
        <img src="static/img/2x/notlogin_pic@2x.png" width="90">
        <br> <br>
        <p v-if="loginData">{{tel|telStr}}</p>
        <p v-if="!loginData">
          <router-link :to="{path:'/login'}" tag="a">去登陆<img src="static/img/2x/login_boult@2x.png" width="8"></router-link>
        </p>
      </div>
    </div>
    <div class="cell">
      <router-link :to="{path:'/noMessage'}" class="box justify-content-space-between">
        <span>消息</span><span><img src="static/img/2x/login_boult_right@2x.png"></span>
      </router-link>
      <router-link :to="{path:'/setAdvise'}" class="box justify-content-space-between">
        <span>联系我们</span><span><img src="static/img/2x/login_boult_right@2x.png"></span>
      </router-link>
    </div>
     <div class="btn-div">
      <mt-button type="primary" class="btn" @click="loginOut" v-if="loginData">退出</mt-button>
    </div> 
  </div>
</template>

<script>
export default {
  name: 'personCenter',
  data () {
    return {
      tel:'13625120448',
      loginData:false
    }
  },
  filters:{
    telStr:function(s){ 
        var s = s.substr(0,3)+"****"+s.substring(7)
        console.log(s)
        return s
    }
  },
  mounted(){
    var isLogin = cookie.get("isLogin");
    this.loginData = isLogin=="true" ? true : false;
  },
  methods:{
    loginOut:function(){
      this.loginData = false
      cookie.set('isLogin','false');
    }
  }
}
</script>

<style scoped>
  .header-bg{
    height:240px;
    width:100%;
    background: url('../../static/img/2x/header_bg@2x.png') no-repeat center center;
    background-size:100% 240px;
    text-align: center
  }
  .header-bg>div>p{
    font-size:14px;
    color:#fff;
    padding:15px 0; 
    letter-spacing: 1px
  }
  .header-bg>div>p a{
    padding:8px 15px;
    border-radius:18px;
    display:inline-block;

    color:#fff;
    border:1px solid rgba(255,255,255,0.3);
  }
  .footer.box{
    height:50px;
    border-top:1px solid #dbdbdb;
    position: fixed;
    bottom:0;width:100%;
    max-width:580px;
    padding:0 30px;
  }
  .footer.box>div{
    text-align: center;
    font-size:12px;
    line-height: 1.6
  }
  .footer.box>div img{
    width:16px;
    height:18px;
  }
  .cell{
    margin-top:5px;
  }
  .cell .box{
    padding:0 10px;
    height:45px;
    line-height: 45px;
    border-top:1px solid #dbdbdb;
  }
  .cell .box:last-child{
    border-bottom:1px solid #dbdbdb;
  }
  .cell .box img{
    height:18px;
  }
  .btn-div{
    margin:80px 10px 20px 10px;
  }
  .btn-div .btn{
    width:100%;
  }
</style>
