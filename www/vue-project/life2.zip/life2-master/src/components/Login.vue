<template>
  <div name="login" class="login">
    <a href="javascript:void(0)" class="close" @click="closeDialog"><img src="static/img/2x/login_close@2x.png" width="20" height="19"></a>
    <img class="logo" src="static/img/2x/login_name@2x.png" >
    <form>
        <div class="box align-items-center">
          <i class="username-icon"></i>
          <input type="text" placeholder="输入手机号码" v-model.trim="tel"  />
        </div>

         <div class="box align-items-center">
          <i class="phonecode-icon"></i>
          <input type="text" placeholder="输入验证码" v-model.trim="code" />
          <span class="get-code" @click="getCode($event)">获取验证码</span>
        </div>
        <mt-button type="primary" class="btn" @click="loginIn($event)">{{btnMsg}}</mt-button>

        <label>
          <input type="checkbox" name="read" value="isRead" style="vertical-align:-2px">已阅读并同意
        </label>
        <router-link :to="{}" active-class="active" tag="a">
          《注册协议》
        </router-link>   
    </form>
    <Tips :msg="errorMsg" v-show="errorShow"></Tips>
    <Loading v-show="loadingShow"></Loading>
  </div>
</template>

<script>
//import cookie from '../../src/assets/js/cookie.js'
export default {
  name: 'login',
  data () {
    return {
      btnMsg: '登陆',
      errorMsg:'',
      errorShow:false,//控制提示信息tips
      loadingShow:false,//控制loading
      eventFlag : true,//获取验证码事件解除与否
      second: 60, // 定时
      tel:'13625120448',
      code:''
    }
  },
  methods:{
    //获取验证码
    getCode:function(obj){
      var secondTemp = this.second;//临时保存定时器
      if(this.eventFlag)
      {
        var cls = setInterval(()=>{
          this.second--;
          if(this.second==0)
          {
              obj.target.innerHTML = "重新获取";
              this.second = secondTemp;
              this.eventFlag = true;
              clearInterval(cls)
          }
          else
          {
            if(secondTemp-1===this.second)
            {
              alert("validate complete ，send ajax...")
              this.code="1357"
            }
            obj.target.innerHTML=this.second+"s";
            this.eventFlag = false;
          } 
        },1000)
      }
    },
    loginIn:function(e){
      e.preventDefault(); 
      //手机号正则  
      var phoneReg = /(^1[3|4|5|7|8]\d{9}$)|(^09\d{8}$)/;  
      //电话  
      if (!phoneReg.test(this.tel)) 
      {  
        this.showErr('请输入正确的手机号码...')
        return false
      } 
      //验证码
      if(this.code==""){
        this.showErr('请输入验证码...')
        return false
      }

      this.loadingShow = true;
      var user = "";
      setTimeout(()=>{
          var user = "123"
          if(user!="")
          {
            this.loadingShow = false
            cookie.set('isLogin','true');
            console.log("登陆成功");
            this.$router.push({"path":"/"});
          } 
      },2000)

     
      
    },
    closeDialog:function(){
      this.$router.push("{path:'/'}")
    },
    showErr:function(txt){
      this.errorMsg = txt;
      this.errorShow = true;

      setTimeout(()=>{
        this.errorMsg = "";
        this.errorShow = false;
      },1500)     
    }
  }
}
</script>

<style scoped>
 .login{position: fixed;max-width: 640px;width:100%;height:100%;background: #fff}
 .close{display:inline-block;margin:10px;padding:5px;}
 .logo{width:180px;display: block;margin:70px auto}
 form{margin:0 10px;}
 form>div{padding:0 10px;border-bottom:1px solid #dbdbdb;height:50px;margin:10px auto;}
 form input[type="text"]{width:100%;font-size:16px;color:#3096fb;border:none;flex:1;}
 .username-icon{background: url('../../static/img/2x/login_cellphone@2x.png') no-repeat center center;background-size:18px 20px;width:18px;height:30px;display:block;margin-right:20px;}
 .phonecode-icon{background: url('../../static/img/2x/login_auth@2x.png') no-repeat center center;background-size:18px 20px;width:18px;height:30px;display:block;margin-right:20px;}
 .get-code{width:100px;display: inline-block;height:32px;line-height: 32px;text-align: center;border:1px solid #dbdbdb;font-size:14px;border-radius: 15px;color:#64a0d6;cursor: pointer;}
 .btn{width:100%;margin:40px auto 10px auto;}
 a.active{color:#64a0d6;}
</style>
