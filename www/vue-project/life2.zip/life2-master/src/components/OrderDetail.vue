<template>
	<div name="orderdetail">
		<v-header msg="清单详情"></v-header>
		<section class="section-list">
			<dl>
				<dt>清单详情</dt>
				<dd>2017-05-08 09:00:12</dd>
			</dl>
			<div class="box justify-content-space-between">
				<div>消费金额：<span class="money">￥500.00</span></div>
				<span>已结清</span>
			</div>
		</section>
		<div class="m20">
			<p class="order-no">订单号：20170509152448</p>
			<div class="box box-header">
				<span class="flex2">商品</span>
				<span class="flex1">单价</span>
				<span class="flex1">数量</span>
				<span class="flex1">总价</span>
			</div>
			<div class="box box-content" v-for="(item,index) in list" :key="index">
				<div class="flex2">
					<p>绿箭35粒金属无糖兰香薄荷糖</p>
					二维码：0215456788979
				</div>
				<div class="flex1">￥10.00</div>
				<div class="flex1">10</div>
				<div class="flex1">￥100.00</div>
			</div>
		</div>
		<div class="total-price m20 box justify-content-flex-end align-items-center">
			<div class="txt-right">
				<p>合计：&yen20000.00</p>
				<p>优惠：&yen10.00</p>
				<p>实付：&yen20000.00</p>
			</div>
		</div>
	</div>
</template>

<script>
import VHeader from './Header'
export default {
	name: 'orderdetail',
	components:{VHeader},
	data () {
		return {
			list:[1,2,3,4,5],
			value:''
		}
	},
	methods:{
		//获取搜索结果列表
		getList:function(obj){
			
		}
	}
}
</script>

<style scoped>
	.section-list{padding:15px 20px; margin-bottom:5px;background: #eff3f6}
	.section-list dt{font-size:16px;color:#333;}
	.section-list dd{padding:5px 0 15px 0;font-size:12px;color:#999;}
	.section-list .box{padding-bottom:5px;}
	.section-list .box div{color:#999;}
	.section-list .money{color:#fb6719;}
	.section-list .box>span{color:#999;}
	.order-no{font-size:12px;color:#64a0d6;padding:8px 0 12px 0;}
	.box-header{height:35px;line-height: 35px;border-top:1px solid #dbdbdb;border-bottom:1px solid #dbdbdb;text-align: center}
	.box-header>span{color:#999;}
	.box-content{margin:15px 0;}
	.box-content .flex1{text-align: center}
	.box-content .flex2{color:#999;font-size:10px;}
	.box-content .flex2 p{padding-right:10px;font-size:14px;color:#333;margin-bottom: 10px}
	.total-price{height:110px;border:1px solid #dbdbdb;background: #eff3f6;margin:30px auto;}
	.total-price>div{padding-right:10px;font-size:16px;color:#333;}
	.total-price>div p:nth-child(2){font-size:13px;color:#999;padding:5px 0 5px 0;}
</style>
