<template>
  <div name="noMessage" class="txt-center">
    <v-header msg="超市购物清单"></v-header>
    <img src="static/img/2x/main_news@2x.png"><br>
    没有新消息
  </div>
</template>

<script>
import VHeader from './Header'
export default {
  name: 'noMessage',
  components:{VHeader},
  data () {
    return {

    }
  }
}
</script>

<style scoped>
  .txt-center{font-size:16px;color:#999;}
  img{width:200px;padding-bottom:20px;padding-top:65px;}
</style>
