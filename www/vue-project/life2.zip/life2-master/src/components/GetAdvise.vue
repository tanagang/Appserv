<template>
  <div name="getAdvise">
     <v-header msg="超市购物清单"></v-header>
     <p class="advise-img"><img src="static/img/2x/main_suggest_gain@2x.png"></p>
     <div class="advise-info">
       <p>您的建议我们已获取</p>
       感谢您的宝贵意见，我们会努力调整
     </div>
  </div>
</template>

<script>
import VHeader from './Header'
export default {
  name: 'getAdvise',
  components:{VHeader},
  data () {
    return {

    }
  }
}
</script>

<style scoped>
  .advise-img{width:190px;height:130px;margin:40px auto 25px auto;}
  .advise-info{text-align: center;color:#999;}
  .advise-info p{font-size:16px;color:#666;line-height: 2}
</style>
