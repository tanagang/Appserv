<template>
  <div name="index">
    <v-header msg="生活助手" :isShow="false"></v-header>
    <mt-swipe :auto="10000" :showIndicators="true">
      <mt-swipe-item class="swipe-item" v-for="(item,index) in imgAttr" :key="index">
        <img :src="item" />
      </mt-swipe-item>
    </mt-swipe>
    <section class="m15">
      <p class="t">生活金融-小借一笔</p>
      <p class="sel-money">{{rangeValue}}</p>
      <mt-range class="mt-range"
        v-model="rangeValue"
        :min="0"
        :max="10000"
        :step="1000"
        :bar-height="8" >
      </mt-range>

      <div class="box justify-content-space-between between">
        <span>1000</span> <span>10000</span>
      </div>

      <div class="sel-option">
        <div>借款期限<span @click="showAction('temp1')">{{sheetTemp.data1}}</span></div>
        <div>您的身份<span  @click="showAction('temp2')">{{sheetTemp.data2}}</span></div>
      </div>
      
      <router-link :to="{'path':'/recommend'}">
            <mt-button type="primary" class="per100">去借款</mt-button>
      </router-link>
      <div class="mt15"><router-link to="{}"><img src="static/img/2x/home_zhongjie@2x.png"></router-link></div>
       <div class="mt15"><router-link to="{}"><img src="static/img/2x/home_life@2x.png"></router-link></div>
    </section>
    <ActionSheet :show="show" :sheetAttr="sheetAttr" @emitData="onData" @hide="hideAction"></ActionSheet>
  </div>
</template>

<script>
import VHeader from './Header'
export default {
  components:{VHeader},
  name: 'index',
  data () {
    return { 
      rangeValue:1000,
      show:false,//默认隐藏actionSheet
      sheetAttr:[],//实际传入actionSheet组件的值
      sheetTempAttr:{//加载actionSheet的值
        temp1:['6个月','12个月'],
        temp2:['工薪族','企业主']
      },
      sheetTemp:{//临时保存页面加载的actionSheet默认值
        data1:'',
        data2:'',
      },
      flag:'',//判断选中哪个actionSheet底部弹窗
      imgAttr:[//轮播图
        require('../../static/img/2x/home_banner@2x.png'),
        require('../../static/img/2x/home_banner@2x.png'),
        require('../../static/img/2x/home_banner@2x.png')
      ]
    }
  },
  mounted(){
    this.sheetTemp.data1 = this.sheetTempAttr.temp1[0]
    this.sheetTemp.data2 = this.sheetTempAttr.temp2[0]
  },
  methods:{
    showAction (v) {
      this.flag = v;
      this.sheetAttr = this.sheetTempAttr[v];
      this.show = true;
    },
    hideAction(){
      this.show = false;
    },
    onData(v){
      if(this.flag=="temp1"){
        this.sheetTemp.data1 = v
      }else{
         this.sheetTemp.data2 = v
      }
       this.show = false;
    }
  }
}
</script>

<style>
  .mint-swipe {
      overflow: hidden!important;
      position: relative!important;
      height: 135px!important;
  }
  .mint-swipe-items-wrap {
      position: relative!important;
      overflow: hidden!important;
      height: 100%!important;
  }
  .mint-swipe-items-wrap > div {
      position: absolute;
      -webkit-transform: translateX(-100%);
              transform: translateX(-100%);
      width: 100%;
      height: 100%;
      display: none
  }
  .mint-swipe-items-wrap > div.is-active {
      display: block;
      -webkit-transform: none;
              transform: none;
  }
  .mint-swipe-indicators {
      position: absolute;
      bottom: 8px;
      left: 50%;
      -webkit-transform: translateX(-50%);
              transform: translateX(-50%);
  }
  .mint-swipe-indicator {
      width: 10px;
      height: 10px;
      display: inline-block;
      border-radius: 100%;
      background: #FFF;
      opacity: 0.5;
      margin: 0 4px;
  }
  .mint-swipe-indicator.is-active {
      background: #fff;
      opacity: 1;
  }
  .t{
    font-size:13px;
    color:#999;
    padding:10px 0;
  }
  .sel-money{color:#F17C08;text-align: center;font-size:32px;font-weight:bold; letter-spacing:1px;margin:20px auto;}
  .mt-range-progress{
    background-color:#fc9908!important;
  }
  .mt-range-thumb{
    width:25px!important;
    height:25px!important;
    top:3px!important;
    background-image: url('../../static/img/2x/home_rmb@2x.png');
    background-repeat: no-repeat;
    background-size:25px 25px!important;
  }
  .mt-range-content{
    margin-right:20px!important;
  }
  .mt-range-runway{
    right:-20px!important;
    height:8px!important;
    background: none!important;
    border: 2px solid #ffe3cc!important; 
    border-top-width: 2px!important;
  }
  .between>span{
    font-size:14px;
    color:#999;
  }
  .sel-option{
    margin:20px auto;
  }
  .sel-option>div{
    margin:10px auto;
  }
  .sel-option>div span{
    border:1px solid #dbdbdb;
    border-radius: 15px;
    color:#64a0d6;
    font-size:14px;
    display:inline-block;
    width:90px;
    height:30px;
    line-height: 30px;
    text-align: center;
    margin:0 10px;
  }
</style>
