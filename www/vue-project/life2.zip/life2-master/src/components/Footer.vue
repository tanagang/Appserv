<template>
  <div name="footer">
    <div style="height:60px;"></div>
    <div class="footer">
      <div class="box align-items-center justify-content-space-between">
          <router-link v-for="(item,index) in footAttr" :to="{path:item.path}" tag="div" active-class="active">
            <img :src="item.src1" @click="getActive(footAttr,item)"><br/>
            {{item.msg}}
          </router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'footers',
  data () {
    return {
      footAttr:[
        {
          path:'/index',
          src1:require('../../static/img/2x/home_icon@2x.png'),
          src2:require('../../static/img/2x/home_icon_click@2x.png'),
          msg:'首页',
        },
        {
          path:'/orderList',
          src1:require('../../static/img/2x/repertoire_icon@2x.png'),
          src2:require('../../static/img/2x/repertoire_icon_click@2x.png'),
          msg:'清单',
        },
        {
          path:'/personCenter',
          src1:require('../../static/img/2x/main_icon@2x.png'),
          src2:require('../../static/img/2x/main_icon_click@2x.png'),
          msg:'我的',
        }
      ]
    }
  },
  methods:{
    getActive:function(v1,v2){
     
    }
  }
}
</script>

<style scoped>
  .footer .box{height:50px;background:#fff;border-top:1px solid #dbdbdb;position: fixed;bottom:0;width:100%;max-width:640px;padding:0 30px; z-index:990;}
  .footer .box>div{text-align: center;font-size:12px;line-height: 1.6}
  .footer .box>div img{width:16px;height:18px;}
  .footer div.active{color:#3096fb;}
</style>
