<template>
  <div name="recommend">
    <v-header msg="产品推荐" :isShow="true"></v-header>
    <p class="recommend-title">以下是我们为您推荐的产品</p>
    <div class="recommend">
      <p><img src="static/img/2x/home_recommend_logo@2x.png">善林租赁-工薪族</p>
      <div class="box">
        <div class="flex2"><p>8%</p>最低年化利率</div>
        <div class="flex3"><p><span>5660</span>人申请成功</p>可分期还款</div>
      </div>
      <p class="lianjie">产品链接已发送至您手机</p>
    </div>
  </div>
</template>

<script>
import VHeader from './Header'
export default {
  name: 'recommend',
  components:{VHeader},
  data () {
    return {

    }
  }
}
</script>

<style scoped>
  .recommend-title{
    text-align: center;
    font-size:18px;
    color:#333;
    padding:20px 0;
  }
  .recommend{
    margin:0 10px;
    border:1px solid #dbdbdb;
    padding:10px
  }
  .recommend>p{
    color:#999;
  }
  .recommend>p img{
    width:20px;
    height:20px;
    vertical-align: -5px;
    margin-right:5px;
  }
  .box{
    text-align: center;
    margin:20px auto;
  }
  .box .flex2{
    border-right:1px solid #dbdbdb;
    color:#999;
  }
  .box .flex2 p{
    color:#49A3E4;
    font-size:36px;
    padding-bottom:6px;
  }
   .box .flex3{
    color:#999;
   }
   .box .flex3 p{
    font-size:18px;
    padding-bottom:4px;
   }
   .box .flex3 p span{
    color:#FC6717;
    letter-spacing: 1px
   }
   .lianjie{
    background: #F2F2F2;
    text-align: center;
    height:30px;
    line-height: 30px;
    margin:0 18px;
   }
</style>
