<template>
  <div name="orderList">
    <v-header msg="超市购物清单"></v-header>
    <mt-search v-model="value"></mt-search>
    
    <section class="section-list" v-for="(item,index) in list" :key="index">
      <router-link :to="{'path':'/orderDetail'}">
        <dl>
          <dt>家乐福高科中路店</dt>
          <dd>2017-05-08 09:00:12</dd>
        </dl>
        <div class="box justify-content-space-between">
          <div>消费金额：<span class="money">￥500.00</span></div>
          <span>已结清</span>
        </div>
      </router-link>
    </section>
  </div>
</template>

<script>
import VHeader from './Header'
export default {
  components:{VHeader},
  name: 'login',
  data () {
    return {
      list:[1,2,3,4,5],
      value:''
    }
  },
  methods:{
    //获取搜索结果列表
    getList:function(obj){
      
    }
  }
}
</script>

<style>
  .section-list{padding:15px 20px; border-top:1px solid #dbdbdb;border-bottom:1px solid #CCCCCC;margin-bottom:5px;background: #fff}
  .section-list dt{font-size:16px;color:#333;}
  .section-list dd{padding:5px 0 15px 0;font-size:12px;color:#999;}
  .section-list .box{padding-bottom:5px;}
  .section-list .box div{font-size:14px;color:#999;}
  .section-list .money{color:#fb6719;}
  .section-list .box>span{color:#999;}
  .mint-search{height:45px!important;}
  .mint-searchbar{background-color:#f8f8f8!important;}
  .mint-searchbar-inner{border:1px solid #dbdbdb;}
</style>
