<template>
  <div>
    <transition name="fade">
        <div class="action_mask" v-show="show" @click="hideAction"></div>
    </transition>
    <transition name="bounce">
        <div class="action" v-show="show">
            <div class="action_content">
                <div class="item" v-for="item in sheetAttr" @click="returnData(item)">{{item}}</div>
            </div>
            <div class="action_btn" @click="hideAction">取消</div>
        </div>
    </transition>
  </div>

</template>

<script>
export default {
      name: 'tips',
      props:['show','sheetAttr'],
      methods: {
          hideAction(){
              this.$emit('hide')
          },
          returnData(v){
              this.$emit('emitData',v)
          }
      }
  }
</script>

<style lang="less">
  .action{
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    text-align: center;
    background-color: #7C7C7C;
    z-index: 999;
    .action_title{
        padding: 0 20px;
        color: #888;
        margin-bottom:1px;
        height: 50px; 
        line-height: 50px;
        background-color: #fff;
    }
    .action_content{
        color: #666;
        .item{
            height:50px;
            line-height: 50px;
             margin-bottom:1px;
            background-color: #fff;
            font-size:22px
        }
    }
    .action_btn{
        height: 50px;
        margin-top: 5px;
        background-color: #fff;
        line-height: 50px;
        font-size:22px
    }
}

.action_mask{
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: #000;
    opacity: 0.5;
    z-index: 998;
}


.bounce-enter-active{transition:all 0.5s ease;}
.bounce-leave-active{transition:all 0.3s ease;}
.bounce-enter{transform:translateY(300px);opacity: 0}
.bounce-leave-active{transform:translateY(300px);opacity: 0}


/*.bounce-enter-active {
  animation: bounce-in .5s;
}
.bounce-leave-active {
  animation: bounce-out .5s;
}
@keyframes bounce-in {
  0% {
    transform: translateY(300px);
  }

  100% {
    transform: translateY(0px);
  }
}
@keyframes bounce-out {
   0% {
    transform: translateY(0px);
  }

  100% {
    transform: translateY(300px);
  }
}

.fade-enter-active {
  animation: fade-in .5s;
}
.fade-leave-active {
  animation: fade-out .5s;
}
@keyframes fade-in {
  0% {
    opacity: 0;
  }

  100% {
    opacity: 0.5;
  }
}
@keyframes fade-out {
   0% {
    opacity: 0.5;
  }

  100% {
    opacity: 0;
  }
}*/
</style>
