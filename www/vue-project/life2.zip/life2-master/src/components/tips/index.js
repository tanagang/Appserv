import TipsComponent			from './Tips'
import UpdateVersionComponent   from './Dialog'
import ActionSheetComponent		from './ActionSheet'
import LoadingComponent			from './Loading'

const Tips ={
    install : function (Vue, options) {
        Vue.component('Tips',TipsComponent);
        Vue.component('UpdateVersion',UpdateVersionComponent);
        Vue.component('ActionSheet',ActionSheetComponent);
        Vue.component('Loading',LoadingComponent);
       /* Vue.myGlobalMethod = function (obj) {//调用Vue.myGlobalMethod({name:"tom",age:12})
          //插件逻辑...
        }*/
    }
} 
export default Tips
