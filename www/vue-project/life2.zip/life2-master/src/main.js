// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import Tips from './components/tips'
import directives from './common/directives'
Vue.use(Tips)//调用 v-touch:swipeleft="methodFunc"
directives(Vue)
// 按需引入部分组件
import { Swipe, SwipeItem, Range,Button,Search,Actionsheet,Cell,Tabbar,TabItem} from 'mint-ui';

Vue.component(Swipe.name, Swipe);
Vue.component(SwipeItem.name, SwipeItem);
Vue.component(Range.name, Range);
Vue.component(Button.name, Button);
Vue.component(Search.name, Search);
//Vue.component(Actionsheet.name, Actionsheet);
//Vue.component(Cell.name, Cell);
//Vue.component(Tabbar.name, Tabbar);
//Vue.component(TabItem.name, TabItem);


import 'mint-ui/lib/style.css'

Vue.config.productionTip = false


router.afterEach((to, from, next) => {
  //定义title
  var routerOptions = router.options.routes;
  for(var i=0;i<routerOptions.length;i++){
    if(to.path==routerOptions[i].path){
        document.title = routerOptions[i].name;
        var m = document.createElement('iframe');
        //m.src = '//m.baidu.com/favicon.ico';
        m.style.display = 'none';
        m.onload = function() {
              setTimeout(function(){
                m.remove();
              }, 10)
       }
      document.body.appendChild(m);
    }
  }

  //判断登陆状态
  var isLogin = cookie.get('isLogin');
  if(isLogin=="true")
  {
    console.log("登陆状态...")
  }
  else if(to.path == "/index" || to.path=="/personCenter")
  {
     router.push({path:to.path})
  }
  else
  {
    console.log("登出状态...")
    router.push({"path":'/login'})
  }
})

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App }
});

//Vue.myGlobalMethod({name:"tom",age:12})调用tips中index.js中的插件方法