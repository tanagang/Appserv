<template>
  <div id="app" >
    <Tips msg="验证错误..." v-show="false"></Tips>
    
	  <router-view></router-view>

    <v-footer v-show="showFooter"></v-footer>

  </div>
</template>
<script>
import Vue from 'vue'
import LoginDialog from './components/Login'
import VHeader from './components/Header.vue'
import VFooter from './components/Footer.vue'
export default {
  name: 'app',
  data () {
  	return{
      selected:2,
     showFooter:true
  	}
  },
  watch:{
    '$route':function(to,from,next){
      if(to.path=="/login"){
        this.showFooter = false
      }else{
         this.showFooter = true
      }
    }
  },
  /*mounted(){
    this.showFooter = Vue.prototype.$showFooter
  },*/
  components:{
  	LoginDialog,
    VFooter,
    VHeader
  }
}
</script>

