/*import Vue            from 'vue'
import Router         from 'vue-router'
import Login          from '@/components/Login'
import Index          from '@/components/Index'
import OrderList      from '@/components/OrderList'
import OrderDetail    from '@/components/OrderDetail'
import PersonCenter   from '@/components/PersonCenter'
import Recommend      from '@/components/Recommend'
import GetAdvise      from '@/components/GetAdvise'
import SetAdvise      from '@/components/SetAdvise'
import NoMessage      from '@/components/NoMessage'

Vue.use(Router)

export default new Router({
  routes: [
    { path: '/login', name: 'Login', component: Login },
    { path: '/index', name: 'index', component: Index },
    { path: '/orderList', name: 'orderList',  component: OrderList },
    { path: '/orderDetail', name: 'orderDetail',  component: OrderDetail },
    { path: '/personCenter',  name: 'personCenter', component: PersonCenter },
    { path: '/recommend', name: 'recommend', component: Recommend },
    { path: '/getAdvise', name: 'getAdvise', component: GetAdvise },
    { path: '/setAdvise', name: 'setAdvise',  component: SetAdvise },
    { path: '/noMessage', name: 'noMessage',  component: NoMessage },
    { path: '/',  redirect: '/index' },
    { path: '*',  redirect: '/index' }
  ]
})
*/




//按需加载页面，防止用户第一次加载时间过长，当build时，肯定也会生成多个js
/*
假如全部路由都使用按需分块加载，那么首屏时间很可能不降反增，
因为首屏对应的组件也同样要在客户端通过jsonp生成async script标签并异步获得
建议不常用的组件可以不使用按需加载

有没有一个办法，既能让所有路由全部按需分块加载，并且完全不影响首屏速度的效果呢？

答案是有的，本文就是介绍如何使用SSR的服务端，来达到这样的效果。
http://www.qingpingshan.com/jb/javascript/210924.html
*/
import Vue            from 'vue'
import Router         from 'vue-router'
Vue.use(Router)

export default new Router({
  routes: [
    { path: '/login', name: 'Login', component:  resolve => require(['@/components/Login'], resolve) },
    { path: '/leftSlide', name: 'leftSlide', component:  resolve => require(['@/components/leftSlide'], resolve) },
    { path: '/index', name: 'index', component:  resolve => require(['@/components/Index'], resolve) },
    { path: '/orderList', name: 'orderList',  component:  resolve => require(['@/components/OrderList'], resolve) },
    { path: '/orderDetail', name: 'orderDetail',  component:  resolve => require(['@/components/OrderDetail'], resolve) },
    { path: '/personCenter',  name: 'personCenter', component:  resolve => require(['@/components/PersonCenter'], resolve) },
    { path: '/recommend', name: 'recommend', component:  resolve => require(['@/components/Recommend'], resolve) },
    { path: '/getAdvise', name: 'getAdvise', component:  resolve => require(['@/components/GetAdvise'], resolve) },
    { path: '/setAdvise', name: 'setAdvise',  component:  resolve => require(['@/components/SetAdvise'], resolve) },
    { path: '/noMessage', name: 'noMessage',  component:  resolve => require(['@/components/NoMessage'], resolve) },
    { path: '/',  redirect: '/index' },
    { path: '*',  redirect: '/index' }
  ]
})
