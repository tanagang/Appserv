import mock from './mock';

export default mock;
