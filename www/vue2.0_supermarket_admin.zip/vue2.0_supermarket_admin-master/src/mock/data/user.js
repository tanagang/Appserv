import Mock from 'mockjs';
const LoginUsers = [
  {
    id: 1,
    username: '善林金融',
    password: '123456',
    avatar: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1491991163769&di=ef1b6b5be4e60374d49027df58486968&imgtype=0&src=http%3A%2F%2Fwww.lagou.com%2Fi%2Fimage%2FM00%2F11%2FA7%2FCgp3O1bia9-AMdXIAADGHM8r32U544.png',
    name: '善林金融'
  }
];

const Users = [];

for (let i = 0; i < 86; i++) {
  Users.push(Mock.mock({
    id: Mock.Random.guid(),
    name: Mock.Random.cname(),
    addr: Mock.mock('@county(true)'),
    'age|18-90': 1,
    birth: Mock.Random.date(),
    sex: Mock.Random.integer(0, 1)
  }));
};

export { LoginUsers, Users }
