<!--我是导入商品页面-->
<template>
    <section>
        <!--上传文件-->
            <el-upload
                    class="upload-demo"
                    action="https://jsonplaceholder.typicode.com/posts/"
                    :on-preview="handlePreview"
                    :on-remove="handleRemove"
                    :file-list="fileList">
                <el-button size="small" type="primary">选择文件</el-button>
            </el-upload>
       <!--导入按钮-->
        <div class="ImportBtn">
            <el-button type="info">开始导入</el-button>
            <el-button type="info" class="templateDown">导入模板下载</el-button>
        </div>

        <!--导入信息-->
        <p>
            本次已导入成功46个商品，导入错误3个商品如下
        </p>

        <el-table
                :data="tableData"
                style="width: 100%">
            <el-table-column
                    prop="number"
                    label="编号"
                    width="180">
            </el-table-column>
            <el-table-column
                    prop="name"
                    label="商品名称"
                    width="180">
            </el-table-column>
            <el-table-column
                    prop="code"
                    label="条形码">
            </el-table-column>
            <el-table-column
                    prop="price"
                    label="销售价">
            </el-table-column>
            <el-table-column
                    prop="wrongResult"
                    label="错误原因">
            </el-table-column>
        </el-table>
    </section>
</template>

<script>
    export default {
        data() {
            return {
                tableData: [{
                    number: '01',
                    name: '王小虎',
                    code: '16895235789',
                    price:'5.0'
                }, {
                    number: '02',
                    name: '王小虎',
                    code: '36799766897',
                    price:'5.0'
                }, {
                    number: '03',
                    name: '王小虎',
                    code: '23697885632',
                    price:'5.0'
                }],
                fileList: [
                            {
                                name: 'food.jpeg',
                                url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
                            },
                            {
                                name: 'food2.jpeg',
                                url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
                            }
                ]
            };
        },
        methods: {
            handleRemove(file, fileList) {
                console.log(file, fileList);
            },
            handlePreview(file) {
                console.log(file);
            }
        }
    }
</script>

<style>
    .templateDown{
        float: right;
    }
    .ImportBtn{
        padding: 20px 0;
        border-bottom: 1px solid #999;
    }

</style>