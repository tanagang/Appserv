<!--我是商品详情页面-->
<template>
    <section> 
        <el-form ref="form" :model="form" label-width="80px" :rules="rules2">
            <el-row>
                <el-col :span="12"><div class="grid-content bg-purple">
                    <h1>基本信息</h1>
                    <el-form-item label="商品名称" class="productInputWidth" prop="goodsName">
                        <el-input v-model="form.goodsName" placeholder="请输入商品名称"></el-input>
                    </el-form-item>
                    <el-form-item label="商品条码" class="productInputWidth" prop="barCode">
                        <el-input v-model="form.barCode" placeholder="请输入商品条码"></el-input>
                    </el-form-item>
                    <el-form-item label="所属分类" prop="gtId">

                        <el-select v-model="form.gtId" placeholder="商品分类">
                            <el-option
                                    v-for="item in options"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="商品库存" class="productInputWidth" prop="goodsStock">
                        <el-input v-model="form.goodsStock" placeholder="请输入商品库存"></el-input>
                    </el-form-item>
                </div></el-col>

                <el-col :span="12"><div class="grid-content bg-purple-light">
                    <h1>商品价格</h1>
                    <el-form-item label="零售价格" class="productInputWidth" prop="retailPrice">
                        <el-input v-model="form.retailPrice" placeholder="单行输入"></el-input>
                    </el-form-item>
                    <el-form-item label="进货价" class="productInputWidth" prop="inPrice">
                        <el-input v-model="form.inPrice" placeholder="单行输入"></el-input>
                    </el-form-item>
                    <h1 class="productWarn">库存预警</h1>
                    <el-form-item label="最低库存" class="productInputWidth" prop="minStock">
                        <el-input v-model="form.minStock"></el-input>
                    </el-form-item>
                </div></el-col>
            </el-row>

            <div class="productBottomBtn">
                <el-form-item>
                    <el-button type="primary" @click="addGoods">保存</el-button>
                    <el-button @click="gotoProduct">取消</el-button>
                </el-form-item>
            </div>
        </el-form>
        <!-- 新增成功后的弹框 -->
        <el-dialog title="提示" v-model="dialogVisible" size="tiny">
          <span>这是一段信息</span>
          <span slot="footer" class="dialog-footer">
            <el-button @click="gotoProductCtrl">返回列表</el-button>
            <el-button type="primary" @click="gotoAddGoods">继续新增</el-button>
          </span>
        </el-dialog>
    </section>
</template>

<script>
    export default {
        data() {
            return {
                form: {
                    goodsName: '',
                    barCode:'',
                    gtId: '',
                    goodsStock:'',
                    minStock:'',
                    inPrice:'',
                    retailPrice:'',
                    storeId:''
                },

                options: [{
                    value: '黄金糕',
                    label: '黄金糕'
                }, {
                    value: '双皮奶',
                    label: '双皮奶'
                }, {
                    value: '蚵仔煎',
                    label: '蚵仔煎'
                }, {
                    value: '龙须面',
                    label: '龙须面'
                }, {
                    value: '北京烤鸭',
                    label: '北京烤鸭'
                }],
                dialogVisible: false
            }
        },
        methods: {
            addGoods() {
                this.$http.post(
                    'http://rapapi.org/mockjsdata/17930/goodsManage/add',
                    {
                        goodsName: '',
                        barCode:'',
                        gtId: '',
                        goodsStock:'',
                        minStock:'',
                        inPrice:'',
                        retailPrice:'',
                        storeId:''
                    },
                    {
                       'headers':{
                         'Content-Type' : 'x-www-form-urlencoded'
                       }
                    }

                 ).then(function(response){
                   
                    this.dialogVisible = true;

                },function(response){

                });
                // console.log(this.form);
            },
            gotoProduct(){
                window.location.href = '#/productCtrl'
            },
            gotoAddGoods(ev){
                this.dialogVisible = false;
                this.$refs.form.validate((valid) => {
                   if (valid) {
                     alert('submit!');
                   } else {
                     console.log('error submit!!');
                     return false;
                   }
                 });
                this.$refs.form.resetFields();
                window.location.href = '#/productAddGoods';
            },
            gotoProductCtrl(){
                this.dialogVisible = false;
                window.location.href = '#/productCtrl'
            }
        }
    }
</script>

<style>
    .productInputWidth{
        width: 70%;
    }
    .productWarn{
        margin-top: 30px;
    }
    .productBottomBtn{
        text-align: center;
        margin-top: 50px;
        margin-left: -200px;
    }
    el-popover{
        position:absolute;
        top:0;
    }

</style>
