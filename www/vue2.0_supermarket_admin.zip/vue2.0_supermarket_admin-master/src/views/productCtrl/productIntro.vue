<!--我是商品详情页面-->
<template>
    <section>
        <el-form ref="form" :model="form" label-width="80px">
            <el-row>
                <el-col :span="12"><div class="grid-content bg-purple">
                    <h1>基本信息</h1>
                    <el-form-item label="商品名称" class="productInputWidth">
                        <el-input v-model="form.name" placeholder="请输入商品名称"></el-input>
                    </el-form-item>
                    <el-form-item label="商品条码" class="productInputWidth">
                        <el-input v-model="form.code" placeholder="请输入商品条码"></el-input>
                    </el-form-item>
                    <el-form-item label="所属分类">

                        <el-select v-model="form.region" placeholder="商品分类">
                            <el-option
                                    v-for="item in options"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="商品库存" class="productInputWidth">
                        <el-input v-model="form.inventory" placeholder="请输入商品库存"></el-input>
                    </el-form-item>
                </div></el-col>

                <el-col :span="12"><div class="grid-content bg-purple-light">
                    <h1>商品价格</h1>
                    <el-form-item label="零售价格" class="productInputWidth">
                        <el-input v-model="form.retail" placeholder="单行输入"></el-input>
                    </el-form-item>
                    <el-form-item label="进货价" class="productInputWidth">
                        <el-input v-model="form.stock" placeholder="单行输入"></el-input>
                    </el-form-item>
                    <h1 class="productWarn">库存预警</h1>
                    <el-form-item label="最低库存" class="productInputWidth">
                        <el-input v-model="form.retail"></el-input>
                    </el-form-item>
                </div></el-col>
            </el-row>

        <div class="productBottomBtn">
            <el-form-item>
                <el-button type="primary" @click="onSubmit">保存</el-button>
                <el-button @click="gotoProduct">取消</el-button>
            </el-form-item>
        </div>
        </el-form>
    </section>
</template>

<script>
    export default {
        data() {
            return {
                form: {
                    goodsName: '',
                    barCode:'',
                    gtId: '',
                    goodsStock:'',
                    minStock:'',
                    inPrice:'',
                    retailPrice:'',
                    storeId:''
                },
                options: [{
                    value: '选项1',
                    label: '黄金糕'
                }, {
                    value: '选项2',
                    label: '双皮奶'
                }, {
                    value: '选项3',
                    label: '蚵仔煎'
                }, {
                    value: '选项4',
                    label: '龙须面'
                }, {
                    value: '选项5',
                    label: '北京烤鸭'
                }]
            }
        },
        methods: {
            onSubmit() {
                console.log('submit!');
            },
            gotoProduct(){
              window.location.href = '#/productCtrl'
            }
        }
    }
</script>

<style>
    .productInputWidth{
        width: 70%;
    }
    .productWarn{
        margin-top: 30px;
    }
    .productBottomBtn{
        text-align: center;
        margin-top: 50px;
        margin-left: -200px;
    }

</style>
