<template>
    <section>
        <!-- 搜索栏 -->
        <div class="t-search" :data="selected">
        	<span>商品条形码:</span><el-input style="width:200px" placeholder="请输入商品条形码" v-model="selected.barCode"></el-input>
            <span style="margin-left:100px">商品名称:</span><el-input style="width:200px;"  placeholder="请输入商品名称" v-model="selected.goodsName"></el-input>
            <el-button type="primary" @click="select">查询</el-button>
        </div>
        <!-- 按钮栏 -->
        <el-row :gutter="20">
         <!--  <el-col :span="3"><div class="grid-content">
          	<el-button type="primary">查询</el-button>
          </div></el-col> -->
          <el-col :span="3"><div class="grid-content">
          	<el-button type="primary" @click="addGoods">新增商品</el-button>
          </div></el-col>
          <el-col :span="3"><div class="grid-content">
          	<el-button type="primary" @click="exportGoods">导入商品</el-button>
          </div></el-col>
          <el-col :span="3"><div class="grid-content">
          	<el-button type="primary">导出商品</el-button>
          </div></el-col>
          <el-col :span="3"><div class="grid-content" :data="tableData" >
          	<el-button scope="scope" type="primary" prop="index" @click="toggle()">失效</el-button>
            </div>
          </el-col>
        </el-row>

        <el-row >
            <el-col :span="4"><div class="grid-content bg-purple">
                <!-- 商品分类 -->
                <span>商品分类</span></br>
                <el-tree
                        :data="data"
                        :props="defaultProps"
                        style="float: left"
                        accordion
                        @node-click="handleNodeClick">

                </el-tree>
            </div></el-col>
            <el-col :span="20"><div class="grid-content bg-purple-light">
                <!-- 商品列表 -->
                <el-table :data="tableData" border tooltip-effect="dark"  @selection-change="handleSelectionChange">
                    <el-table-column scope="scope" type="selection" width="auto" @change="change(tableData.index)"></el-table-column>
                    <el-table-column label="编号" width="auto" type="index" prop="index">

                    </el-table-column>
                    <el-table-column prop="goodsName" label="商品名称" width="auto" scope="scope">
                        <!-- <template scope="scope">{{ scope.row.date }}</template> -->
                        <template>
                            <span style="margin-left: 10px"></span>
                        </template>
                    </el-table-column>
                    <el-table-column label="条形码" width="auto" prop='barCode'></el-table-column>
                    <el-table-column label="销售价" width="auto" prop='retailPrice'></el-table-column>
                    <el-table-column label="状态" width="auto" prop='status' v-model="tableData.status"></el-table-column>
                    <el-table-column label="操作" width="auto">
                        <template scope="scope"><el-button size='small' @click="detail()">详情</el-button></template>
                    </el-table-column>
                </el-table>

            </div></el-col>
        </el-row>
        <!-- 分页按钮 -->
        <div class="block">
           <span class="demonstration"></span>
           <el-pagination
             @size-change="handleSizeChange"
             @current-change="handleCurrentChange"
             :current-page="currentPage1"
             :page-size="5"
             layout="prev, pager, next, jumper"
             :total=total>
           </el-pagination>
        </div>
    </section>
</template>

<script>
	export default {
	  data() {
	    return {
	      input: '',
        // 商品分类
	      data: [{
               name: '日常用品',
               tcId: 0 ,
               children: [{
                 name: '毛巾',
                 tcId: 0 ,
                 secId: 0,
                 children: [{
                    name: '毛巾1',
                    tcId: 0 ,
                    secId: 10,
                   },
                   {
                    name: '毛巾2',
                    tcId: 0 ,
                    secId: 9,
                   },
                   {
                    name: '毛巾3',
                    tcId: 0 ,
                    secId: 8,
                   }

                ],

                },
                 {
                 name: '盆',
                 tcId: 0 ,
                 secId: 1,
                }
                ]
               }, 
                {
               name: '家电',
               tcId: 0 ,
               children: [{
                 name: '电饭煲',
                 tcId: 0 ,
                 secId: 2,
                }, 
                  {
                 name: '电磁炉',
                 tcId: 0 ,
                 secId: 3,
                },
                  {
                 name: '彩电',
                 tcId: 0 ,
                 secId: 4,
                }]
                }, 
                {
               name: '服装',
               tcId: 0 ,
               children: [{
                 name: '上衣',
                 tcId: 0 ,
                 secId: 5,
                 }, 
                 {
                 name: '连衣裙',
                 tcId: 0 ,
                 secId: 6,
               }]
            }],
          defaultProps: {
             children: 'children',
             label: 'name'
          },
          // data: [],
          // 商品initinit列表参数
          tableData:[],
          //选择框事件触发获取对象
          multipleSelection: [],
          // 被选择的选项的参数
          selected:{
               barCode:'',
               goodsName:''
           },
          // 分页按钮参数
          currentPage1: 5,
          total:30
           
	     }
	  },

	  methods: {
      // 增加商品
      addGoods(){
        location.href='#/productAddGoods'
      },
      // 导入商品
      exportGoods(){
        location.href='#/productImportCtrl'
      },
      // 查询商品按钮
      select(){
        console.log(this.selected);
        var url='http://rapapi.org/mockjsdata/17930/goodsManage/search';
        this.$http.post(
            url,
            this.selected,
            {
              'headers':{
                'Content-Type':'x-www-form-urlencoded'
              }
            }
          ).then(function(response){
              if(response.body.code == 200){
                this.tableData=response.body.goodsInfoDto;
              }
              
          },function(response){
            alert("网络失败");

          })

      },
      // 点击选择商品
       handleRemove(file, fileList) {
        console.log(file, fileList);
       },
       handlePreview(file) {
        console.log(file);
       },

 	     handleNodeClick(data) {
         console.log(data.name);
         console.log(data.secId);
 	     },
       // select选择时间
 	     handleSelectionChange(val) {
           this.multipleSelection = val;
           
       },
       // 详情
       detail(){
           // window.location.href='#/productintro';
           var arr=[];
           for(var i=0;i<this.multipleSelection.length;i++){
              
              arr.push(this.multipleSelection[i].id);
              console.log("arr===="+arr);

           }

           var url='http://rapapi.org/mockjsdata/17930/goodsManage/detail';
           this.$http.post(
            url,
            {
              id:this.multipleSelection.id
            },{
              'headers':{
                'Content-Type':'x-www-form-urlencoded'
              }
            }
          ).then(function(response){
              if(response.body.code===200){
                
                console.log(response.body.id);
                
              }

          },function(response){

          })

       },
       
       // post请求商品列表,从cookie拿到storeId
       getRoute:function(){
        var that = this;
        that.$http({
            method:'POST',
            url:'http://rapapi.org/mockjsdata/17930/goodsManage/init',
            data:{
              storeId:'1111111'
            },
            headers:{
                'Content-Type':'x-www-form-urlencoded'
            }
           }).then(function(response){
            //请求成功回调
               if(response.body.code == '200'){
                  this.tableData = response.body.goodsInfoDto;
                  // this.data = response.body.goodsTypeDto.data;
                  console.log(this.data);

               }
        },function(response){
            //请求失败回调
        })
 	     },
       // 失效按钮点击事件
       toggle:function(){
          var arr=[];
          for(var i=0;i<this.multipleSelection.length;i++){
            arr.push(this.multipleSelection[i].barCode);
          }
          var url='http://rapapi.org/mockjsdata/17884/shixiao';
          this.$http.post(
            url,
            {
              barCode:arr
            },{
              'headers':{
                'Content-Type':'x-www-form-urlencoded'
              }
            }
          ).then(function(response){
              if(response.body.code===200){
                this.tableData.status="失效"
                console.log(response.body.code);
                console.log(this.tableData.status)
              }

          },function(response){

          })

          console.log(arr);
          
       },
       change:function(index){
         
        console.log(index);
       },
       // 分页事件
       handleSizeChange(val) {
        console.log(val);
        console.log(`每页 ${val} 条`);
        },
       handleCurrentChange(val) {
        this.currentPage = val;
        console.log(`当前页: ${val}`);
       }
    },
    created:function(){
       this.getRoute();
   }
}
  
</script>

<style>
    .el-row {
    margin-bottom: 20px;
    margin-top: 13px;
    &:last-child {
      margin-bottom: 0;
      }
    }
    .el-col {
      border-radius: 4px;
    }
    .bg-purple-dark {
      background: #99a9bf;
    }
    /* .bg-purple {
      background: #d3dce6;
    } */
    /* .bg-purple-light {
      background: #e5e9f2;
    } */
    .grid-content {
      border-radius: 4px;
      min-height: 36px;
    }
    .row-bg {
      padding: 10px 0;
      background-color: #f9fafc;
    }
    .el-tree{
    	width: 200px;
    	height: 80%;
    	border: none;
    }
    .block{
      position:absolute;
      bottom: 0px;
      left: 45%;
    }
	
</style>
