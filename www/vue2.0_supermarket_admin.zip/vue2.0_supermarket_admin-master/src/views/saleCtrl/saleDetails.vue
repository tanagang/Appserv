<template>
    <section class="content">
        <el-col :span="24">
            <el-form :inline="true">
                <el-col >
                    <el-form-item>
                    	活动名称：<input class='tradName' placeholder="请输入商品名称"></input>
                    </el-form-item>
                    <el-form-item>
                    	活动时间：
                        <el-date-picker v-model="value1" type="datetime" placeholder="选择日期时间">
                        </el-date-picker>
                        <el-date-picker v-model="value2" type="datetime" placeholder="选择日期时间">
                        </el-date-picker>
                        <div class="btn-save"><el-button  type="primary">保存</el-button></div> 
                    </el-form-item>
                </el-col>
            </el-form>
        </el-col>
        <hr>
        <!--列表-->
       <el-table :data='tableDate' highlight-current-row  style="width: 100%;" >
            
            <el-table-column type="index" prop='number' label="编号" width="100">
            </el-table-column>
            <el-table-column prop="barCode" label="条形码" >
            </el-table-column>
            <el-table-column prop="goodsName" label="商品名称" >
            </el-table-column>
            <el-table-column prop="retailPrice" label="原零售价" >

            </el-table-column>
            <el-table-column prop="disPrice" label="折扣" >
            </el-table-column>
            <el-table-column prop="proPrice" label="活动价格" >
            </el-table-column>
        </el-table>

        
        <div class="booter" >
            <hr>
            <el-row :gutter="20" class="stockDetailRemark">
                <el-col :span="2"><div class="grid-content bg-purple ">备注：</div></el-col>
                <el-col :span="10"><div class="grid-content bg-purple stockLayout">
                    <el-input
                            type="textarea"
                            :rows="3"
                            :maxlength = "100"
                            resize="none"
                            placeholder="最多不超过100字"
                            v-model="textarea">
                    </el-input>
                </div></el-col>
                <el-col :span="12" ><div class="grid-content bg-purple stockLayout">
                   
                </div></el-col>
            </el-row>
            <hr>
            <div class="lister">
                <div class="lister-person">
                    制单人：{{ from.name }} &nbsp; 制表时间: {{ from.data }}
                </div>           
                <div class="lister-btn">
                    <el-button type="primary">上一单</el-button>
                    <el-button type="primary">下一单</el-button>
                </div>    
            </div>
        </div>
    </section>
</template>

<script>
    import util from '../../common/js/util'
    export default {
        data() {
            return {
                textarea:'',
                from:{
                    name:'阿珍',
                    data:'2017-5-2'
                },
                tableDate:[
                ],
                value1:'',
                value2:''              
            }
        },
        methods:{
            getData(){
                this.$http.post('http://rapapi.org/mockjsdata/18333/timeLimitSaleSet/seleteById',{id:"this.$route.query.id"}).then(function(response){
                    this.tableDate = response.body.promotionGoodsInfoDto;
                    console.log(response.body.promotionGoodsInfoDto)
                   
                })
            }
        	
        },
        mounted(){
            this.getData();
        }
    }
</script>


<style>
	hr{
		margin:15px;
	}
    .btn-save{
        display: inline-block;
        position: relative;
        margin-left: 300px;
    }
    
    .title {
        display: inline-table;
    }
    .tradName{

    	height: 30px;
    	width: 180px;
    	border: none;
    	border-bottom: 1px;
    }
    .content{
        position: relative;
        height: 500px;
    }
    .booter{
        position: absolute;
        left: 0;
        right: 0;
        bottom: 5px;
    }

    .lister-person{
       float: left;
   }
   .lister-btn{
       float: right;
   }
   

</style>