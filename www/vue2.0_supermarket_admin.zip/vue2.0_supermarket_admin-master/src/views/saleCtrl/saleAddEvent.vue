<template>
    <section class="content">
        <el-col :span="24">
            <el-form :inline="true">
                <el-col>
                    <el-form-item v-model='tradName'>
                    	活动名称：<input class='tradName' v-model='tradName'   placeholder="请输入活动名称"></input>
                    </el-form-item>
                    <el-form-item>
                    	活动时间：
                        <el-date-picker v-model="beginTime" type="datetime" placeholder="2017-5-1 00:00">
                        </el-date-picker>
                        <el-date-picker v-model="endTime" type="datetime" placeholder="2017-5-2 00:00">
                        </el-date-picker>
                    </el-form-item>
                
                </el-col>
            </el-form>
        </el-col>
        <hr>
        <!--列表-->
        <el-table id='el-table' ref="tableA" :data='tableDate' highlight-current-row  style="width: 100%; min-height: 350px" >
            <el-table-column id = 'number' type="index" prop='number' label="编号" width="100">
            </el-table-column>

            <el-table-column  prop="rebate" label="条形码"  >
                <template scope="scope">
                    <!-- <el-date-picker v-model="value3" type="input" placeholder="67890098" id='rebate1' ></el-date-picker> -->

                    <el-input v-model="scope.row.rebate"></el-input>
                    
                </template>
            
            </el-table-column>
            <el-table-column  prop="tradName1" label="商品名称" >
               <template scope="scope">
                            <el-select v-model="formInline.region" placeholder="农夫山泉矿泉水" id='tradName1'>
                              <el-option label="低糖" value="shanghai"></el-option>
                              <el-option label="低脂肪" value="beijing"></el-option>
                            </el-select>
                        </el-form-item>
                </template>
            </el-select>
            </el-table-column>
            <el-table-column  prop="retailPrice" label="原零售价" >
            </el-table-column>
            <el-table-column prop="rebate1" label="折扣" >
                <template scope="scope">
                    <el-date-picker v-model="value4" type="input" placeholder="请输入折扣" >
                    </el-date-picker>
                </template>
            </el-table-column>
            <el-table-column prop="eventPrice" label="活动价格" >
                <template scope="scope">
                    <el-date-picker v-model="value5" type="input" placeholder="请输入活动价格" >
                    </el-date-picker>
                </template>
            </el-table-column>
        </el-table>
        <el-button type="primary" class='addBtn' @click = "AddDataList()">增加一行</el-button>

            <hr>
            <el-row :gutter="20" class="stockDetailRemark">
                <el-col :span="2"><div class="grid-content bg-purple ">备注：</div></el-col>
                <el-col :span="10"><div class="grid-content bg-purple stockLayout">
                    <el-input
                            type="textarea"
                            :rows="3"
                            :maxlength = "100"
                            resize="none"
                            placeholder="如果你无法简明的表达你的想法，只能说明你还不了解它。--阿尔伯特爱恩斯坦"
                            v-model="textarea">
                    </el-input>
                </div></el-col>
                <el-col :span="12" ><div class="grid-content bg-purple stockLayout">
                   
                </div></el-col>
            </el-row>
            <hr>
            <div class="lister">
                <div class="lister-person">
                    制单人：{{ from.name }} &nbsp; 制表时间: {{ from.data }}
                </div>           
                <div class="lister-btn">
                    <el-button type="primary">取消</el-button>
                    <el-button type="primary" @click='saveData( tableDate )'>保存</el-button>
                </div>    
            </div>
    </section>
</template>

<script>
    import util from '../../common/js/util'
    export default {
        data() {
            return {
                textarea:'',
                from:{
                    name:'阿珍',
                    data:'2017-5-2'
                },
                tradName:'',
                tableDate:[
                    {
                        rebate:'111',
                        retailPrice:2.00
                    },{
                        rebate:'222',
                        retailPrice:2.00
                    },{
                        rebate:'333',
                        retailPrice:2.00
                    },{
                        rebate:'444',
                        retailPrice:2.00
                    },{
                        rebate:'555',
                        retailPrice:2.00
                    },{
                        rebate:'666',
                        retailPrice:2.00
                    }
                ],
                rebate:'',
                beginTime:'',
                endTime:'' ,
                value3:'' ,
                value4:'' ,
                value5:'' ,
                formInline: {
                  user: '',
                  region: ''
                }             
            }
        },
        methods:{
            saveData( scope ){
               
               console.log(scope);

            },
            keydown(){
                var text = document.getElementById('text');
                var regC = /[^ -~]+/g;
                var regE = /\D+/g;
                var str = text.value; 
                if (regC.test(str)){
                    text.value = text.value.substr(0,100);
                }

                if(regE.test(str)){
                    text.value = text.value.substr(0,20);
                }
            },
            AddDataList(){
                //var index =  this.tableDate.length + 1;
                this.tableDate.push({
                        rebate:'',
                        retailPrice:''
                    })
            }
            
        	
        }
    }
</script>


<style>
	hr{
		margin:15px;
	}
    
    .title {
        display: inline-table;
    }
    .tradName{

    	height: 30px;
    	width: 180px;
    	border: none;
    	border-bottom: 1px;
    }
    .content{
        position: relative;
        height: 500px;
    }
    .booter{
        position: absolute;
        left: 0;
        right: 0;
        bottom: 5px;
    }
    .addBtn{
        margin-top: 15px;
    }

    .lister-person{
       float: left;
   }
   .lister-btn{
       float: right;
   }
   

</style>