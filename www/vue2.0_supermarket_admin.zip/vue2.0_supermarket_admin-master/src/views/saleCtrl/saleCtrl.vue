<template>
    <section class="content">
        <el-col :span="24">
            <el-form :inline="true">
                <el-col>
                    <el-form-item>
                        <el-button type="info" @click="addEvent()">新增活动</el-button>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="info" @click="deletData(tableDate)">删除活动</el-button>
                    </el-form-item>
                    <el-form-item>
                    	商品名称：
                           <input class="tradName" placeholder="请输入商品名称" v-model="searchgoods" @keyup="get($event)" @keydown.enter="get($event)" @keydown.down="selectDown(tableDate)" @keydown.up.prevent="selectUp()"/>
                          <div class="search-select" id="search-select">
                           <transition-group tag="ul" mode="out-in">
                            <li v-for="(value,index) in myData" :class="{selectback:index==now}" :key="index" @click="searchThis(index)" @mouseover="selectHover(index)" class="search-select-option search-select-list">
                             {{value}}
                            </li>
                           </transition-group>
                         </div>
                    </el-form-item>
                    <el-form-item>
                    	活动名称：<input type="text" class="tradName" placeholder="请输入活动名称">
                    </el-form-item>
                    <el-form-item>
                        <el-button type="info" >搜索</el-button>
        </el-form-item>
                </el-col>
            </el-form>
            
        </el-col>
        <hr>
        <!--列表-->
        <el-table  :data='tableDate' highlight-current-row  style="width: 100%;" @selection-change = 'handleSelectionChange'>
           <!--  <el-table-column v-if='false'  type="input" display='none' prop='id'>
           </el-table-column> -->
            <el-table-column type="selection" width="40">
            </el-table-column>
            <el-table-column type="index" prop='number' label="编号"  width="70">
            </el-table-column>
            <el-table-column prop="proName" label="活动" width="90" >
            </el-table-column>
            <el-table-column prop='beginTime' label="开始时间" width="210"  >
            	
            </el-table-column>
            <el-table-column prop='endTime'  label="结束时间"  width="210">
            </el-table-column>
            <el-table-column prop="goodsName" label="商品名称" >
            </el-table-column>
            <el-table-column prop="updateAt" label="更新时间" >
            </el-table-column>
            <el-table-column prop="status" label="状态" >
            </el-table-column>
            <el-table-column label="操作" width="150">
                <template scope="scope">
                    <el-button type="danger"  size="small" @click="details( scope )">详情</el-button>
                </template>
            </el-table-column>
        </el-table>
         <!-- 分页 -->
        <div id="paging">       
            <el-row :gutter="20">
              <el-col :span="8"><div class="grid-content bg-purple"></div></el-col>
              <el-col :span="8"><div class="grid-content bg-purple">
                <div class="block">
                <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage1" :page-size="100" layout="total, prev, pager, next" :total="1000">
                </el-pagination>
              </div>
              </div></el-col>
              <el-col :span="8"><div class="grid-content bg-purple"></div></el-col>
            </el-row>
        </div>
    </section>
</template>

<script>
    import util from '../../common/js/util'
    export default {
        data() {
            return {
                myData:[],
                searchgoods:[],
                multipleSelection:[],
                now:0,
            	pickerOptions0: {
		          disabledDate(time) {
		            return time.getTime() < Date.now() - 8.64e7;
		          }
       		 	},
       		 	pickerOptions1: {
		          disabledDate(time) {
		            return time.getTime() < Date.now() - 8.64e7;
		          }
       		 	},
            	tableDate:[
            	],
                promotionGoodsInfoDto:[],
            	value1:'',
            	value2:'',
            	currentPage1: 5,
		        currentPage2: 5,
		        currentPage3: 5,
		        currentPage4: 4
                
            }
        },
        methods:{
            handleSelectionChange(model) {
                this.multipleSelection = model;
            },
            deletData(){
                var selectChoose = this.multipleSelection;
                var arr=[];
                for(var i=0;i<selectChoose.length;i++){
                    arr.push(selectChoose[i].id);
                }
                console.log(arr);
                this.$http.post('http://rapapi.org/mockjsdata/18333/timeLimitSaleSet/delete',{ids:arr}).then(function(response){
                    console.log(response.body)

                })

            },
        	handleSizeChange(val) {
		        // console.log(`每页 ${val} 条`);
		    },
		    handleCurrentChange(val) {
		        this.currentPage = val;
		        // console.log(`当前页: ${val}`);
		    },
            details( vue ){
                // console.log( vue )
                // window.location.href='#/saleDetails';
                // console.log(vue)
                // console.log(vue.row.id)
                // console.log(vue.row.goodsName)
                
                var id = vue.row.id
                console.log(vue)
                 window.location.href = '#/saleDetails?id='+id


            },
            addEvent(){
                window.location.href='#/saleAddEvent'
            },
            get: function(event) {
                // console.log(2)
                 if(event.keyCode == 38 || event.keyCode == 40){ //向上向下
                  return ;
                 }
                 this.$http.jsonp('https://sug.so.360.cn/suggest?word=' + this.searchgoods + '&encodein=utf-8&encodeout=utf-8').then(function(res) {
                  this.myData = res.data.s;


                 }, function() {

                 });
            },
            clearInput: function() {
               this.searchgoods = '';
               this.get(event);
            },
              //搜索
              /*searchInput: function(event) {
               // alert(this.flag)
               // window.open(this.logoData[this.flag].searchSrc+this.search);
               this.get(event);
              },*/
              //搜索的内容
            searchThis: function(index) {
               this.search = this.myData[index];
               var searchSelect = document.getElementById("search-select")
               if (searchSelect.style.display=="block"){
                    searchSelect.style.display="none";
                } else {
                    searchSelect.style.display="block";
                }

               // this.searchInput();
            },
              //li hover
            selectHover: function(index) {
               this.searchgoods = this.myData[index];
               this.now = index;
            },
              //向下
            selectDown: function() {
               this.now++;
               if(this.now == this.myData.length) {
                this.now = 0;
               }
               this.searchgoods = this.myData[this.now];
            },
              //向上
            selectUp: function() {
               this.now--;
               if(this.now == -1) {
                this.now = this.myData.length - 1;
               }
               this.searchgoods = this.myData[this.now];
            },
            getData(){
                // var that = this;
                this.$http.get('http://rapapi.org/mockjsdata/18333/timeLimitSaleSet/init').then(function(response){
                    // debugger
                    // this.tableDate.push(response.body);
                    this.tableDate = response.body.timeLimitSaleDto;
;
                    // console.log(this.tableDate)
                })
              }
        },
        mounted(){
            this.getData();
        }
    }
</script>


<style>
	hr{
		margin:15px;
	}
    .title {
        display: inline-table;
    }
    .tradName{

    	height: 30px;
    	width: 180px;
    	border: none;
    	border-bottom: 1px;
    }
    .el-row {
    margin-bottom: 20px;
    &:last-child {
      margin-bottom: 0;
    }
  }
  .el-col {
    border-radius: 4px;
  }
  .bg-purple-dark {
    background: #99a9bf;
  }
  .bg-purple {
    background: #fff;
  }
  /* .bg-purple-light {
    background: #e5e9f2;
  } */
  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }
  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
  }
  #paging{
    position: absolute;
    bottom: 5px;
    left: 0;
    right: 0
  }
 

</style>