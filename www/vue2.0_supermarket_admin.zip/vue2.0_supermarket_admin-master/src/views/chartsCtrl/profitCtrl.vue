<template>
    <section>
        <el-col :span="24">
            <el-form :inline="true">
                <el-col>
                    <el-form-item>
                        <el-button type="info">导出报表</el-button>
                    </el-form-item>
                    <el-form-item label="商品信息：">
                        <el-input placeholder="输入商品名称、条形码"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <div>
                            <span class="demonstration">时间</span>
                            <el-date-picker v-model="value1" type="date" placeholder="请选择时间" :picker-options="pickerOptions0">
                            </el-date-picker>
                        </div>
                    </el-form-item>
                    <el-form-item>
                        <div>
                            <span class="demonstration">--</span>
                            <el-date-picker v-model="value2" type="date" placeholder="请选择时间" :picker-options="pickerOptions0">
                            </el-date-picker>
                        </div>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="info">查询</el-button>
                    </el-form-item>
                </el-col>
            </el-form>
        </el-col>
        <!--列表-->
        <el-row style="margin-bottom: 10px">
            <el-col :span="12">
                <div class="grid-content bg-purple" style="text-align: center">
                    收支项目
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    金额
                </div>
            </el-col>
        </el-row>
        <el-row  style="margin-bottom: 10px">
            <el-col :span="12">
                <div class="grid-content bg-purple">
                    收入类
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    12312312313
                </div>
            </el-col>
        </el-row>
        <el-row  style="margin-bottom: 10px;font-size: 12px">
            <el-col :span="11" :offset="1">
                <div class="grid-content bg-purple">
                    销售毛利
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    98.00
                </div>
            </el-col>
        </el-row>
        <el-row  style="margin-bottom: 10px;font-size: 12px">
            <el-col :span="11" :offset="1">
                <div class="grid-content bg-purple">
                    收入科目
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    98.00
                </div>
            </el-col>
        </el-row>
        <el-row  style="margin-bottom: 10px;font-size: 12px">
            <el-col :span="11" :offset="1">
                <div class="grid-content bg-purple">
                    收入科目
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    98.00
                </div>
            </el-col>
        </el-row>
        <el-row  style="margin-bottom: 10px;font-size: 12px">
            <el-col :span="11" :offset="1">
                <div class="grid-content bg-purple">
                    收入科目
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    98.00
                </div>
            </el-col>
        </el-row>
        <el-row  style="margin-bottom: 10px">
            <el-col :span="12">
                <div class="grid-content bg-purple">
                    支出类
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    12312312313
                </div>
            </el-col>
        </el-row>
        <el-row  style="margin-bottom: 10px;font-size: 12px">
            <el-col :span="11" :offset="1">
                <div class="grid-content bg-purple">
                    退款金额
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    98.00
                </div>
            </el-col>
        </el-row>
        <el-row style="margin-bottom: 10px;font-size: 12px">
            <el-col :span="11" :offset="1">
                <div class="grid-content bg-purple">
                    支出账目
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    98.00
                </div>
            </el-col>
        </el-row>
        <el-row style="margin-bottom: 10px;font-size: 12px">
            <el-col :span="11" :offset="1">
                <div class="grid-content bg-purple">
                    支出账目
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    98.00
                </div>
            </el-col>
        </el-row>
        <el-row style="margin-bottom: 10px;font-size: 12px">
            <el-col :span="11" :offset="1">
                <div class="grid-content bg-purple">
                    支出账目
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    98.00
                </div>
            </el-col>
        </el-row>
        <el-row style="margin-bottom: 10px;font-size: 12px">
            <el-col :span="11" :offset="1">
                <div class="grid-content bg-purple">
                    付款优惠
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    98.00
                </div>
            </el-col>
        </el-row>
        <el-row style="margin-bottom: 10px">
            <el-col :span="12">
                <div class="grid-content bg-purple">
                    利润
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple-light">
                    12312312313
                </div>
            </el-col>
        </el-row>
    </section>
</template>

<script>
    import util from '../../common/js/util'
    export default {
        data() {
            return {
                pickerOptions0: {
                    disabledDate(time) {
                        return time.getTime() < Date.now() - 8.64e7;
                    }
                },
                pickerOptions1: {
                    shortcuts: [{
                        text: '今天',
                        onClick(picker) {
                            picker.$emit('pick', new Date());
                        }
                    }, {
                        text: '昨天',
                        onClick(picker) {
                            const date = new Date();
                            date.setTime(date.getTime() - 3600 * 1000 * 24);
                            picker.$emit('pick', date);
                        }
                    }, {
                        text: '一周前',
                        onClick(picker) {
                            const date = new Date();
                            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', date);
                        }
                    }]
                },
                value1: '',
                value2: '',
                note_acountIncome: false,
                textarea: '',
                options: [{
                    value: '1',
                    label: '利息收入'
                }, {
                    value: '2',
                    label: '投资收入'
                }, {
                    value: '3',
                    label: '其他收入'
                }],
                optionOne: '',
                types: [{
                    value: '1',
                    label: '现金账户'
                }, {
                    value: '2',
                    label: '微信账户'
                }, {
                    value: '3',
                    label: '支付宝账户'
                }, {
                    value: '4',
                    label: '银行卡账户'
                }],
                optionTwo: '',
            };
        }
    };
</script>


<style>
    .title {
        display: inline-table;
    }
</style>