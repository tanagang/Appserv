<template>
    <section>
        <el-col :span="24">
            <el-form :inline="true">
                <el-col>
                    <el-form-item>
                        <el-button type="info">导出报表</el-button>
                    </el-form-item>
                    <el-form-item label="商品信息：">
                        <el-input placeholder="输入商品名称、条形码"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <div>
                            <span class="demonstration">时间</span>
                            <el-date-picker v-model="value1" type="date" placeholder="请选择时间" :picker-options="pickerOptions0">
                            </el-date-picker>
                        </div>
                    </el-form-item>
                    <el-form-item>
                        <div>
                            <span class="demonstration">--</span>
                            <el-date-picker v-model="value2" type="date" placeholder="请选择时间" :picker-options="pickerOptions0">
                            </el-date-picker>
                        </div>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="info">查询</el-button>
                    </el-form-item>
                </el-col>
            </el-form>
        </el-col>
        <!--列表-->
        <el-table highlight-current-row  style="width: 100%;">
            <el-table-column type="index" label="序号" width="80">
            </el-table-column>
            <el-table-column prop="Pname" label="商品名称">
            </el-table-column>
            <el-table-column prop="Pcode" label="条形码">
            </el-table-column>
            <el-table-column prop="Pout" label="出库量">
            </el-table-column>
            <el-table-column prop="Pin" label="入库量">
            </el-table-column>
            <el-table-column prop="Pstore" label="当前库存">
            </el-table-column>
            <el-table-column prop="Pprice" label="进货价">
            </el-table-column>
            <el-table-column prop="Ptotal" label="库存总额">
            </el-table-column>
        </el-table>
    </section>
</template>

<script>
    import util from '../../common/js/util'
    export default {
        data() {
            return {
                pickerOptions0: {
                    disabledDate(time) {
                        return time.getTime() < Date.now() - 8.64e7;
                    }
                },
                pickerOptions1: {
                    shortcuts: [{
                        text: '今天',
                        onClick(picker) {
                            picker.$emit('pick', new Date());
                        }
                    }, {
                        text: '昨天',
                        onClick(picker) {
                            const date = new Date();
                            date.setTime(date.getTime() - 3600 * 1000 * 24);
                            picker.$emit('pick', date);
                        }
                    }, {
                        text: '一周前',
                        onClick(picker) {
                            const date = new Date();
                            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', date);
                        }
                    }]
                },
                value1: '',
                value2: '',
                note_acountIncome: false,
                textarea: '',
                options: [{
                    value: '1',
                    label: '利息收入'
                }, {
                    value: '2',
                    label: '投资收入'
                }, {
                    value: '3',
                    label: '其他收入'
                }],
                optionOne: '',
                types: [{
                    value: '1',
                    label: '现金账户'
                }, {
                    value: '2',
                    label: '微信账户'
                }, {
                    value: '3',
                    label: '支付宝账户'
                }, {
                    value: '4',
                    label: '银行卡账户'
                }],
                optionTwo: '',
            };
        }
    };
</script>


<style>
    .title {
        display: inline-table;
    }
</style>