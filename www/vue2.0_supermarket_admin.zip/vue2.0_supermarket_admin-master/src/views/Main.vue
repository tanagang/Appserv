<template>
    <section>
        <div style="border: 1px solid #eee;height: 50px;margin-bottom: 20px;padding-left: 10px;line-height: 50px">
            <!--<span>公告：</span>-->
            <marquee behavior="scroll" loop="-1" scrollamount="5" scrolldelay="100" onMouseOver="this.stop()"  onMouseOut="this.start()">
                <a href="">【善林公益】善林金融泗阳分公司员工，关爱自闭症儿童...</a>
                <a href="">【善林公益】善意社区“不做大负翁”公益项目走进重庆...</a>
                <a href="">【善林公益】第三批中南财经政法志愿者开展小海星财商...</a>
            </marquee>
        </div>
        <el-row style="margin-bottom: 20px">
            <el-col :span="20">
                <div class="grid-content bg-purple">
                    <div style="display: inline">
                        <span class="demonstration">时间：</span>
                        <el-date-picker v-model="value1" type="date" placeholder="选择日期" :picker-options="pickerOptions0">
                        </el-date-picker>
                    </div>
                    <div style="display: inline">
                        <span class="demonstration">--</span>
                        <el-date-picker v-model="value2" align="right" type="date" placeholder="选择日期" :picker-options="pickerOptions1">
                        </el-date-picker>
                    </div>
                </div>
            </el-col>
            <el-col :span="2">
                <div class="grid-content bg-purple">
                    <el-button type="primary">查询</el-button>
                </div>
            </el-col>
        </el-row>

        <el-row :gutter="20">
            <el-col :span="12">
                <div id="chartColumn" style="width:100%; height:400px;"></div>
            </el-col>
            <el-col :span="12">
                <div id="chartBar" style="width:100%; height:400px;"></div>
            </el-col>
        </el-row>
        <el-row>
            <el-col :span="12">
                <el-row>
                    <el-col :span="24">
                        <div class="grid-content bg-purple">
                            <h1>退货数据</h1>
                        </div>
                    </el-col>
                </el-row>
                <el-row style="border: 1px solid #eee">
                    <el-col :span="12" style="border-right: 1px solid #eee">
                        <div class="grid-content bg-purple">
                            <ul class="reData">
                                <li>退货金额</li>
                                <li><h1>￥ 98.00</h1></li>
                            </ul>
                        </div>
                    </el-col>
                    <el-col :span="12">
                        <div class="grid-content bg-purple-light">
                            <ul class="reData">
                                <li>退货笔数</li>
                                <li><h1>12</h1></li>
                            </ul>
                        </div>
                    </el-col>
                </el-row>
            </el-col>
        </el-row>
    </section>
</template>

<script>
    import echarts from 'echarts'
    export default {
        data() {
            return {
                chartColumn: null,
                chartBar: null,
                pickerOptions1: {
                    disabledDate(time) {
                        return time.getTime() < Date.now() - 8.64e7;
                    }
                },
                pickerOptions0: {
                    shortcuts: [{
                        text: '今天',
                        onClick(picker) {
                            picker.$emit('pick', new Date());
                        }
                    }, {
                        text: '昨天',
                        onClick(picker) {
                            const date = new Date();
                            date.setTime(date.getTime() - 3600 * 1000 * 24);
                            picker.$emit('pick', date);
                        }
                    }, {
                        text: '一周前',
                        onClick(picker) {
                            const date = new Date();
                            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', date);
                        }
                    }, {
                        text: '一个月前',
                        onClick(picker) {
                            const date = new Date();
                            date.setTime(date.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', date);
                        }
                    }]
                },
                value1: '',
                value2: '',
                message: [
                    '公告：【善林公益】善意社区“不做大负翁”公益项目走进重庆...',
                    '公告：【善林公益】第三批中南财经政法志愿者开展小海星财商...',
                    '公告：【善林公益】“善者如林基金”援建刘庄小学图书馆开馆...']
            };
        },
        mounted: function () {
            var _this = this;
            this.chartColumn = echarts.init(document.getElementById('chartColumn'));
            this.chartBar = echarts.init(document.getElementById('chartBar'));

            this.chartColumn.setOption({
                title: {text: '销售额(元)'},
                tooltip: {
                    trigger: 'axis'
                },
                calculable: true,
                xAxis: [{
                    type: 'category',
                    data: ['周一','周二','周三','周四','周五','周六','周日']
                }],
                yAxis: [{
                    type: 'value'
                }],
                series: [{
                    name: '销量',
                    type: 'line',
                    data: [22325, 9324, 3456, 13987, 6547, 12321, 15578]
                }]
            });

            this.chartBar.setOption({
                title: {text: '销售笔数'},
                tooltip: {},
                xAxis: {
                    data: ['周一','周二','周三','周四','周五','周六','周日']
                },
                yAxis: {},
                series: [{
                    name: '销量',
                    type: 'line',
                    data: [22, 9, 3, 13, 6, 12, 15]
                }]
            });
        }
    };

</script>

<style scoped>
    marquee a{
        text-decoration: none;
        margin-right: 100px;
        color: black;
    }
    marquee a:hover{
        color: #20a0ff;
       text-decoration: underline;
    }
    .reData {
        list-style: none;
        text-align: center;
    }

    .el-carousel__container {
        display: none;
    }
</style>
