<!--我是退货管理-->
<template>
    <section>
        <!--头部按钮begin-->
        <el-row>
            <el-col :span="24"><div class="grid-content">
                <el-button type="info" @click="AddChoose = true" >新增退货单</el-button>
                <el-button type="info">导出退货单</el-button>
                <el-button type="info" @click="returnFailure()">失效</el-button>
            </div></el-col>
        </el-row>

        <!--头部筛选框-->
        <el-row>
            <el-form :inline="true" :model="formInline" class="demo-form-inline">
                <el-col :span="6"><div class="grid-content bg-purple">
                    <span>商品名称:</span>
                    <el-input style="width:200px"
                              placeholder="请输入商品信息"
                              v-model="formInline.goodsName">

                    </el-input>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple-light">
                    <span>商品条形码:</span>
                    <el-input style="width:200px"
                              placeholder="请输入商品条形码"
                              v-model="formInline.goodsName">
                    </el-input>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple-light">
                    <span>单据编号:</span>
                    <el-input style="width:200px"
                              placeholder="请输入单据编号"
                              v-model="formInline.outsCode">

                    </el-input>
                </div></el-col>
                <el-col :span="6" style="width: 22%;">
                    <div class="grid-content bg-purple">
                        <span>供应商:</span>
                        <el-select v-model="formInline.suppId" placeholder="请选择供应商">
                            <el-option
                                    v-for="item in providerOptions"
                                    :key="item.id"
                                    :label="item.suppName"
                                    :value="item.id">
                            </el-option>
                        </el-select>
                    </div>
                </el-col>
                <el-col :span="6" style="margin-top: 20px"><div class="grid-content bg-purple">
                    <span>状态:</span>
                    <el-select v-model="formInline.insStatus" placeholder="请选择状态">
                        <el-option
                                v-for="item in stockStatus"
                                :key="item.value"
                                :label="item.statusName"
                                :value="item.value">
                        </el-option>
                    </el-select>
                </div></el-col>
                <el-col :span="17" style="margin-top: 20px;text-align: right"><div class="grid-content bg-purple">
                    <el-button type="primary"  @click="returnListSearch(formInline)" icon="search">搜索</el-button>
                </div></el-col>
            </el-form>
        </el-row>

        <!--列表-->
        <el-table highlight-current-row
                  @selection-change="returnSelectionChange"
                  :data="retrunList"
                  border
                  tooltip-effstockect="dark"
                  style="width: 100%;">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column type="index" label="编号" width="100">
            </el-table-column>
            <el-table-column prop="createdAt" label="业务时间" sortable>
            </el-table-column>
            <el-table-column prop="outsCode" label="单据编号" sortable>
            </el-table-column>
            <el-table-column prop="insCode" label="关联进货单号" sortable>
            </el-table-column>
            <el-table-column prop="suppName" label="供应商名称" sortable>
            </el-table-column>
            <el-table-column prop="goodsName" label="商品名称" sortable>
            </el-table-column>
            <el-table-column prop="totalAmount" label="总计金额" sortable>
            </el-table-column>
            <el-table-column prop="refundAmount" label="实退金额" sortable>
            </el-table-column>
            <el-table-column prop="refundAmount" label="单据状态" sortable>
            </el-table-column>
            <el-table-column label="操作" width="150">
                <template scope="scope">
                    <el-button size="small" @click="gotoReturnDetails(scope.row)">详情</el-button>
                </template>
            </el-table-column>
        </el-table>

        <!--分页-->
        <div class="stockPage">
            <el-row type="flex" class="row-bg" justify="space-around" style="margin-top: 10px;">
                <el-col :span="6"><div class="grid-content bg-purple"></div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple-light">
                    <el-pagination
                            :page-size="30"
                            layout="prev, pager, next, jumper"
                            :total=total>
                    </el-pagination>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple"></div></el-col>
            </el-row>
        </div>

        <!--跳转选择   弹框-->
        <el-dialog class="returnDialogChoose" title="提示" v-model="AddChoose" size="tiny">
            <span>您可以关联进货单，也可以直接选择商品进行退货</span>
            <div class="returnChoose">
                <el-button class="returnChooseOne"  @click="gotoStockReturn = true" type="info">关联进货单据退货</el-button>
                <el-button class="returnChooseTwo"  @click="gotoSalesReturn()" type="info">按商品退货</el-button>
            </div>
            </span>
        </el-dialog>

        <!--进货单据退后   弹框-->
        <el-dialog title="进货单据退货" size="large" v-model="gotoStockReturn">
            <!--头部筛选框-->
            <el-row class="stockSelect">
                <el-form :inline="true" :model="formDialog" class="demo-form-inline">
                    <el-col :span="5"><div class="grid-content bg-purple">
                        <span>商品名称:</span>
                        <el-input v-model="formDialog.goodsName"
                                  style="width:200px"
                                  placeholder="请输入商品名称">

                        </el-input>
                    </div></el-col>
                    <el-col :span="5"><div class="grid-content bg-purple">
                        <span>商品条形码:</span>
                        <el-input v-model="formDialog.goodsName"
                                  style="width:200px"
                                  placeholder="请输入商品条形码">

                        </el-input>
                    </div></el-col>
                    <el-col :span="5"><div class="grid-content bg-purple-light">
                        <span>单据编号:</span>
                        <el-input v-model="formDialog.insCode"
                                  style="width:200px"
                                  placeholder="请输入单据编号">

                        </el-input>
                    </div></el-col>
                    <el-col :span="6" style="width: 22%;">
                        <div class="grid-content bg-purple">
                            <span>供应商:</span>
                            <el-select v-model="formDialog.suppName" placeholder="请选择供应商">
                                <el-option
                                        v-for="item in providerOptions"
                                        :key="item.id"
                                        :label="item.suppName"
                                        :value="item.id">
                                </el-option>
                            </el-select>
                        </div>
                    </el-col>
                    <el-col :span="2" style="float: right"><div class="grid-content bg-purple" >
                        <el-button type="primary" @click="returnDialogSearch(formDialog)" icon="search">搜索</el-button>
                    </div></el-col>
                </el-form>
            </el-row>

            <!--列表-->
            <el-table highlight-current-row
                      :data="retrunDialogList"
                      border
                      tooltip-effstockect="dark"
                      style="width: 100%;">
                <el-table-column type="index" label="编号" width="100">
                </el-table-column>
                <el-table-column prop="createdAt" label="业务时间"  sortable>
                </el-table-column>
                <el-table-column prop="insCode" label="单据编号" sortable>
                </el-table-column>
                <el-table-column prop="suppName" label="供应商名称" sortable>
                </el-table-column>
                <el-table-column prop="goodsName" label="商品名称" sortable>
                </el-table-column>
                <el-table-column prop="paidAmount" label="已付金额" sortable>
                </el-table-column>
                <el-table-column prop="insStatus" label="入库状态" sortable>
                </el-table-column>
                <el-table-column label="操作" width="150">
                    <template scope="scope">
                        <el-button size="small" @click="returnCargo(scope.row)">退货</el-button>
                    </template>
                </el-table-column>
            </el-table>

        </el-dialog>
    </section>
</template>

<script>
    export default {
        data() {
            return {
                total:60,
                stockStatus:[{
                    value:'0',
                    statusName:'正常'
                },{
                    value:'1',
                    statusName:'失效'
                }],
                listSelection:[],
                pageQuery:{},
                providerOptions: [],
                AddChoose:false,
                gotoStockReturn:false,
                formInline: {
                    goodsName: '',
                    outsCode: '',
                    suppId:''
                },
                formDialog: {
                    goodsName: '',
                    suppName: '',
                    insCode:''
                },
                retrunList:[],
                retrunDialogList:[]
            }
        },
        methods: {
            //弹框头部搜索
            returnDialogSearch(_search){
                this.$http.post(
                        'http://rapapi.org/mockjsdata/18333/inStockSet/init',
                            _search
                ).then(function(res){
                    if(res.body.code == 200){
                        this.retrunDialogList = res.body.inStockInfoDto;
                    }
                })
            },
            //多选框数据
            returnSelectionChange(model){
                this.listSelection = model;
            },
            //点击失效
            returnFailure(){
                var selectChoose = this.listSelection;
                var arr=[];
                for(var i=0;i<selectChoose.length;i++){
                    arr.push(selectChoose[i].id);
                }
                console.log(arr);
                this.params = {
                    barCode:arr
                };
                this.clickPase();
            },
            //点击失效接口
            clickPase(){
                this.$http.post('http://rapapi.org/mockjsdata/18333/outStockSet/failure',this.params)
                        .then(function(rep) {
                    if( rep.body.code == 200){
                        // console.info(rep.body);
                    }
                })
            },
            //退货管理列表接口
            getListData(){
                this.$http.get('http://rapapi.org/mockjsdata/18333/outStockSet/init')
                        .then(function(rep) {
                            if(rep.status == 200){
                                this.retrunList = rep.body.outStockInfoDto;
                                this.pageQuery = rep.body.pageInfo;
                            }
                })
            },
            //列表页面搜索
            returnListSearch(_search){
                this.$http.post(
                        'http://rapapi.org/mockjsdata/18333/outStockSet/init',
                        _search
                ).then(function(res){
                    if(res.status == 200){
                        this.retrunList = res.body.outStockInfoDto
                    }
                })
            },
            //供应商下拉框
            supplierSelect(){
                this.$http.get('http://rapapi.org/mockjsdata/18333/sysSupplierSet/select')
                        .then(function(res){
                            if(res.status == 200){
                                this.providerOptions = res.body.sysSupplierDto;
                            }
                        })
            },
            //跳转退货详情
            gotoReturnDetails(params){
                window.location.href='#/returnDetailsCtrl/'+params.id;
            },
            //跳转新增退货
            gotoReturnAdd(){
                window.location.href='#/returnAddCtrl'
            },
            //跳转退货列表
            gotoSalesReturn(){
                window.location.href='#/returnListCtrl'
            },
            //跳转新增退货
            returnCargo(params){
                window.location.href = '#/returnAddCtrl/'+params.id
            },

        },
        mounted:function(){
            this.getListData();
            this.supplierSelect();
        }
    }
</script>

<style>
    .returnChoose{
        overflow: hidden;
        margin-top: 30px;
    }
    .returnChooseOne{
        float: left;
    }
    .returnChooseTwo{
        float: right;
    }
</style>
