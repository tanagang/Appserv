<template>
    <section>
        <el-row class="stockDetailTop">
            <el-col :span="12" ><div class="grid-content bg-purple">
                <span>进货单单据编号：<span v-model="allData.outstockInfoDto.insCode">{{allData.outstockInfoDto.insCode}}</span></span>
            </div></el-col>
            <el-col :span="12" class="stockDetailNum"><div class="grid-content bg-purple">
                <span>退货单单据编号：<span v-model="returnCode">{{returnCode}}</span></span>
            </div></el-col>
        </el-row>
        <!--列表-->
        <el-row class="stockDetailList">
            <el-col :span="24"><div class="grid-content bg-purple-dark">
                <el-table highlight-current-row
                          border
                          :data="allData.outstockGoodsDetailDto"
                          style="width: 100%;">
                    <el-table-column type="index" label="编号" width="100">
                    </el-table-column>
                    <el-table-column prop="barCode" label="条形码" sortable>
                    </el-table-column>
                    <el-table-column prop="goodsName" label="商品名称" sortable>
                    </el-table-column>
                    <el-table-column prop="amount" label="数量" sortable>
                    </el-table-column>
                    <el-table-column prop="price" label="单价" sortable>
                    </el-table-column>
                    <el-table-column prop="money" label="金额" sortable>
                    </el-table-column>

                </el-table>
            </div></el-col>
        </el-row>

        <el-row :gutter="20" class="stockDetailRemark">
            <el-col :span="2"><div class="grid-content bg-purple ">备注：</div></el-col>
            <el-col :span="10"><div class="grid-content bg-purple stockLayout">
                <el-input
                        type="textarea"
                        :rows="3"
                        :maxlength = "100"
                        resize="none"
                        placeholder="最多不超过100字"
                        v-model="allData.outstockInfoDto.insDesc">
                </el-input>
            </div></el-col>
            <el-col :span="12" ><div class="grid-content bg-purple stockLayout">
                <span>合计：</span>
                <span>{{allData.outstockInfoDto.totalAmount}}</span>
            </div></el-col>
        </el-row>

        <div class="returnAddBottom">
            <el-row :gutter="20">
                <el-col :span="8"><div class="grid-content">
                </div></el-col>
                <el-col :span="16"><div class="grid-content ">
                    <el-form :inline="true" class="demo-form-inline">
                        <el-form-item label="结算账户">
                            <el-select v-model="allData.outstockInfoDto.accountId" placeholder="请选择">
                                <el-option
                                        v-for="item in balanceOptions"
                                        :key="item.id"
                                        :label="item.name"
                                        :value="item.id">
                                </el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="实退金额">
                            <el-input v-model="allData.outstockInfoDto.refundAmount" placeholder="请输入金额"></el-input>
                        </el-form-item>
                    </el-form>
                </div></el-col>

            </el-row>
        </div>

        <div class="returnBtn">
            <el-button type="info" @click="returnSave(allData)">保存</el-button>
            <el-button type="info" @click="cancel()">取消</el-button>
        </div>


    </section>
</template>

<script>
    export default {
        data() {
            return {
                returnCode:'',
                reselect:false,
                balanceOptions:[],
                allData:{
                    outstockInfoDto:{
                        accountId:'',
                        insCode:'',
                        outsDesc:'',
                        refundAmount:'',
                        totalAmount:''
                    },
                    outstockGoodsDetailDto:[]
                }
            }
        },
        methods: {
            //结算账户（下拉框）
            balanceSelect(){
                this.$http.get('http://10.1.15.190:9005/sysAccountSet/select')
                        .then(function(res){
                            if(res.body.code == '000000'){
                                this.balanceOptions = res.body.sysAccountDto
                            }
                        })
            },
            //页面初始化数据
            getListData(){
                this.$http.post(
                        'http://rapapi.org/mockjsdata/18333/inStockSet/detail',
                        {
                            id:this.$route.params.id
                        }
                ).then(function(rep) {
                    if(rep.body.code == "200"){
                        this.allData.outstockGoodsDetailDto = rep.body.instockGoodsDetailDto;
                        this.allData.outstockInfoDto = rep.body.instockInfoDto;
                    }
                })
            },
            //获取单据编号
            documentCode(){
                this.$http.post(
                        'http://rapapi.org/mockjsdata/18333/inStockSet/getInsCode',
                        {
                            seqType:'03'
                        }
                )
                        .then(function(rep){
                            if(rep.body.code == 200){
                                this.returnCode = rep.body.insCode;
                            }
                        })
            },
            cancel(){
                window.location.href = '#/returnCtrl';
            },
            //点击保存
            returnSave(_params){
                this.$http.post(
                        'http://rapapi.org/mockjsdata/18333/outStockSet/addByInsCode',
                        _params
                ).then(function(res){
                    if(res.body.code == 200){
                        window.location.href = '#/returnCtrl';
                    }else{
                        alert(保存失败);
                    }
                })
            },
            returnCargo(){
                this.reselect = false;
            }
        },
        mounted:function(){
            this.balanceSelect();
            this.getListData();
            this.documentCode();
        }
    }
</script>

<style>
    .returnBtn{
        text-align: right;
        padding-top: 20px ;
    }
    .returnAddBottom{
        margin-top: 20px;
        text-align: right;
    }
</style>