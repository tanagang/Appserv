<!--我是进货管理-->
<template>
    <section>
        <!--头部按钮begin-->
        <el-row>
            <el-col :span="24"><div class="grid-content">
                <el-button type="info" @click="gotoAdd()" >新增进货</el-button>
                <el-button type="info" @click="exportBills(formInline)">导出进货单</el-button>
                <el-button type="info" @click="past(stockList)">失效</el-button>
            </div></el-col>
        </el-row>

        <!--头部筛选框-->

        <el-row>
            <el-form :inline="true" :model="formInline" class="demo-form-inline">
                <el-col :span="6"><div class="grid-content bg-purple">
                    <span>商品名称:</span>
                    <el-input style="width:200px"
                              placeholder="请输入商品信息"
                              v-model="formInline.goodsName">
                    </el-input>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple-light">
                    <span>商品条形码:</span>
                    <el-input style="width:200px"
                              placeholder="请输入商品条形码"
                              v-model="formInline.barCode">
                    </el-input>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    <span>单据编号:</span>
                    <el-input style="width:200px"
                              placeholder="请输入单据编号"
                              v-model="formInline.insCode">

                    </el-input>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple-light">
                    <span>供应商:</span>
                    <el-select v-model="formInline.suppId" placeholder="请选择供应商">
                        <el-option
                                v-for="item in providerOptions"
                                :key="item.id"
                                :label="item.suppName"
                                :value="item.id">
                        </el-option>
                    </el-select>
                </div></el-col>
                <el-col :span="6" style="margin-top: 20px"><div class="grid-content bg-purple">
                    <span>状态:</span>
                    <el-select v-model="formInline.status" placeholder="请选择状态">
                        <el-option
                                v-for="item in stockStatus"
                                :key="item.value"
                                :label="item.statusName"
                                :value="item.value">
                        </el-option>
                    </el-select>
                </div></el-col>
                <el-col :span="17" style="margin-top: 20px;text-align: right"><div class="grid-content bg-purple-light">
                    <el-button type="primary"  @click="stockListSearch(formInline)" icon="search">搜索</el-button>
                </div></el-col>
            </el-form>
        </el-row>
        <!--列表-->
        <el-table highlight-current-row
                  @selection-change="handleSelectionChange"
                  :data="stockList"
                  border
                  tooltip-effstockect="dark"
                  style="width: 100%;">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column type="index" label="编号" width="100">
            </el-table-column>
            <el-table-column prop="createdAt" label="业务时间"  sortable>
                <template scope="scope">
                    {{scope.row.createdAt | timeCycle}}
                </template>
            </el-table-column>
            <el-table-column prop="insCode" label="单据编号" sortable>
            </el-table-column>
            <el-table-column prop="suppName" label="供应商名称" sortable>
            </el-table-column>
            <el-table-column prop="goodsName" label="商品名称" sortable>
            </el-table-column>
            <el-table-column prop="paidAmount" label="实付金额" sortable>
            </el-table-column>
            <el-table-column prop="insStatus" label="入库状态" sortable>
                <template scope="scope">
                    {{scope.row.insStatus | storageType}}
                </template>
            </el-table-column>
            <el-table-column prop="status" label="状态" sortable>
                <template scope="scope">
                    {{scope.row.status | taskType}}
                </template>
            </el-table-column>
            <el-table-column label="操作" width="150">
                <template scope="scope">
                    <el-button size="small" @click="gotoDetails(scope.row)">详情</el-button>
                </template>
            </el-table-column>
        </el-table>
        <!--分页-->
        <div class="stockPage">
            <el-row type="flex" class="row-bg" justify="space-around" style="margin-top: 10px;">
                <el-col :span="6"><div class="grid-content bg-purple"></div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple-light">
                    <el-pagination
                            @current-change="handleCurrentChange"
                            :current-page="currentPage1"
                            :page-size="30"
                            layout="prev, pager, next, jumper"
                            :total=total>
                    </el-pagination>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple"></div></el-col>
            </el-row>
        </div>

    </section>
</template>

<script>
    export default {
        data() {
            return {
                params:{},
                arr:[],
                multipleSelection:[],
                myData:[],
                now: -1,
                providerOptions: [],
                stockStatus:[{
                    value:'0',
                    statusName:'正常'
                },{
                    value:'1',
                    statusName:'失效'
                }],
                formInline: {
                    goodsName:'',
                    insCode:'',
                    status:'',
                    barCode:'',
                    suppId:''
                },
                stockList:[],
                total: 300,
                currentPage1:1,
                queryParams:{
                    pageNum: "1",
                    pageSize: "30",
                    pages: "3"
                }
            }
        },
        methods: {

            //多选框数据
            handleSelectionChange(model) {
                this.multipleSelection = model;
            },
            //点击失效
            past(){
                var selectChoose = this.multipleSelection;
                var arr=[];
                for(var i=0;i<selectChoose.length;i++){
                    arr.push(selectChoose[i].id);
                }
                console.log(arr);
                this.params = {
                    ids:arr
                };
                this.clickPase();
            },
            //页数改变
            handleCurrentChange(val){
                this.queryParams.pages = val;
                this.queryParams.pageNum = val;
                this.getStockList();
            },
            //进货单列表接口
            getStockList(){
                var vm = this;
                vm.$http.post(
                    'http://10.1.15.190:9005/inStockSet/init',
                    {
                        "pageNum": vm.queryParams.pageNum
                    }
                ).then(function(rep) {
                    if(rep.body.code == "000000"){
                        vm.stockList = rep.body.inStockInfoDtoList;
                        vm.queryParams = rep.body.pageInfo;
                        vm.total = parseInt(rep.body.pageInfo.total);
                    }
                })
            },
            //导出
            exportBills(_params){
                this.$http.post(
                        'http://rap.taobao.org/mockjsdata/18333/inStockSet/export',
                        _params
                ).then(function(res){
                })
            },
            //点击失效接口
            clickPase(){
                this.$http.post(
                        'http://rapapi.org/mockjsdata/18333/inStockSet/failure',
                        this.params
                ).then(function(rep) {
                    if( rep.body.code == 200){
                       // console.info(rep.body);
                    }
                })
            },
            //搜索
            stockListSearch(_search){
                var url='http://rapapi.org/mockjsdata/18333/inStockSet/init';
                this.$http.post(
                        url,
                        _search
                ).then(function(res){
                    if(res.status == 200) {
                        this.stockList = res.body.inStockInfoDto;
                    }
                })
            },
            //供应商（下拉框）
            supplierSelect(){
              this.$http.get('http://rapapi.org/mockjsdata/18333/sysSupplierSet/select')
                      .then(function(res){
                          if(res.body.code == 200) {
                              this.providerOptions = res.body.sysSupplierDto;
                          }
                      })
            },
            get() {
                if(event.keyCode == 38 || event.keyCode == 40){  //向上向下
                    return ;
                }
                this.$http.jsonp('https://sug.so.360.cn/suggest?word=' + this.formInline.user1 + '&encodein=utf-8&encodeout=utf-8').then(function(res) {
                    this.myData = res.data.s;

                }, function() {

                });
            },
            //搜索》》键盘enter
            searchInput: function(event) {
                //this.search = this.myData[index];
            },

            //搜索的内容》》当前li的点击事件
            searchThis: function(index) {
                this.formInline.user1 = this.myData[index];
                this.now = index;
                var searchSelect =  document.getElementById('searchSelect');
                searchSelect.style.display = 'none';
                this.get();
            },

            //向下
            selectDown: function() {
                this.now++;
                if(this.now == this.myData.length) {
                    this.now = 0;
                }
                this.formInline.user1 = this.myData[this.now];
            },
            //向上
            selectUp: function() {
                this.now--;
                if(this.now == -1) {
                    this.now = this.myData.length - 1;
                }
                this.formInline.user1 = this.myData[this.now];
            },

            //跳转进货单详情页
            gotoDetails(params){
                window.location.href='#/stockDetailsCtrl/'+params.id;
            },
            //跳转新增进货单
            gotoAdd(){
                window.location.href='#/stockAddCtrl'
            }
        },
        mounted:function(){
            this.getStockList();
            this.supplierSelect();
        },
        filters:{
            taskType,
            timeCycle,
            storageType
        }
    }
    //状态
    function taskType(val){
        let res = '';
        switch (val){
            case '0':
                res = '正常';
                break;
            case '1':
                res = '失效';
                break;
            default:
                break;
        }
        return res;
    }
    //入库状态
    function storageType(_type){
        let res = '';
        switch (_type){
            case '0':
                res = '已入库';
                break;
            case '1':
                res = '已退回';
                break;
            default:
                break;
        }
        return res;
    }

    //时间格式化
    function timeCycle(_time){
        function add0(m) {
            return m < 10 ? '0' + m : m
        }
        var time = new Date(parseInt(_time));
        var y = time.getFullYear();
        var m = time.getMonth() + 1;
        var d = time.getDate();
        return y + '.' + add0(m) + '.' + add0(d);
    }
</script>

<style>
    .stockPage{
        position: absolute;
        left: 0px;
        right: 0px;
        bottom: 10px;
    }
    .stockSelect{
        padding: 10px 0px;
    }
    .stockInput{
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        background-color: #fff;
        background-image: none;
        border-radius: 4px;
        border: 1px solid #bfcbd9;
        box-sizing: border-box;
        color: #1f2d3d;
        display: block;
        font-size: inherit;
        height: 36px;
        line-height: 1;
        outline: 0;
        padding: 3px 10px;
        transition: border-color .2s cubic-bezier(.645,.045,.355,1);
        width: 100%;
    }
    .stockInput:hover {
        border-color: #8391a5;
    }
    .searchSelect{
        z-index: 1111;
        position: absolute;
        background-color: #fff;
    }
    .searchSelect ul{
        list-style: none;
        padding: 0;
    }
    .searchSelect ul li:hover{
        background-color: #999;
    }
</style>
