<!--<div>我是进货单详情</div>-->
<template>
    <section>
        <el-row class="stockDetailTop">
            <el-col :span="12" ><div class="grid-content bg-purple">
                <span>供应商：<span v-model="formParticulars.suppName">{{formParticulars.suppName}}</span></span>
            </div></el-col>
            <el-col :span="12" class="stockDetailNum"><div class="grid-content bg-purple">
                <span>单据编号：<span v-model="formParticulars.insCode">{{formParticulars.insCode}}</span></span>
            </div></el-col>
        </el-row>


    <!--列表-->
        <el-row class="stockDetailList">
            <el-col :span="24"><div class="grid-content bg-purple-dark">
                <el-table highlight-current-row
                          border
                          :data="stockList"
                          style="width: 100%;">
                    <el-table-column type="index" label="编号" width="100">
                    </el-table-column>
                    <el-table-column prop="barCode" label="条形码" sortable>
                    </el-table-column>
                    <el-table-column prop="goodsName" label="商品名称" sortable>
                    </el-table-column>
                    <el-table-column prop="amount" label="数量" sortable>
                    </el-table-column>
                    <el-table-column prop="price" label="单价" sortable>
                    </el-table-column>
                    <el-table-column prop="money" label="金额" sortable>
                    </el-table-column>

                </el-table>
            </div></el-col>
        </el-row>

        <el-row :gutter="20" class="stockDetailRemark">
            <el-col :span="2"><div class="grid-content bg-purple ">备注：</div></el-col>
            <el-col :span="10"><div class="grid-content bg-purple stockLayout">
                <el-input
                type="textarea"
                :maxlength = "100"
                resize="none"
                :rows="3"
                placeholder="最多不超过100字"
                v-model="formParticulars.insDesc">
                </el-input>
            </div></el-col>
            <el-col :span="12" ><div class="grid-content bg-purple stockLayout">
               <span>合计：</span>
                <span>{{formParticulars.totalAmount}}</span>
            </div></el-col>
        </el-row>

        <div class="stockDetailBottom">
            <el-row :gutter="20">
                <el-col :span="6"><div class="grid-content bg-purple">
                    制单人：<span>{{formParticulars.createdBy}}</span>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    制单时间：<span>{{formParticulars.createdAt}}</span>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    结算账户： <span>{{formParticulars.accountId}}</span>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    实付金额： <span>{{formParticulars.paidAmount}}</span>
                </div></el-col>
            </el-row>
        </div>

        <div class="stockDetailNext">
            <el-button-group size="small">
                <el-button type="primary" icon="arrow-left">上一单</el-button>
                <el-button type="primary">下一单<i class="el-icon-arrow-right el-icon--right"></i></el-button>
            </el-button-group>
        </div>

    </section>
</template>

<script>
    export default {
        data() {
            return {
                //获得进货详情数据
                formParticulars:{},
                //进货详情列表
                stockList:[]
            }
        },
        methods: {
            detailsData(){
                this.$http.post(
                    'http://10.1.15.190:9005/inStockSet/detail',
                    {
                        id:this.$route.params.id
                    }
                ).then(function(rep){
                    if(rep.status == 200){
                        this.stockList = rep.body.instockGoodsDetailDto;
                        this.formParticulars =rep.body.inStockInfoDto
                    }
                })
            }
        },
        mounted:function(){
            this.detailsData();
        }
    }
</script>

<style>
    .stockDetailTop{
        width: 100%;
        padding: 10px 0;
    }
    .stockDetailNum{
        text-align: right;
    }
    .stockDetailList{
        min-height: 350px;
        border-bottom: 1px solid #999;
    }
    .stockLayout{
        text-align: center;
        vertical-align: middle;
    }
    .stockDetailRemark{
        padding: 20px 0px;
    }
    .stockDetailBottom{
        width: 100%;
        height: 50px;
        line-height: 50px;
        border-top: 1px solid #999;
    }
    .stockDetailNext{
        text-align: right;
        padding: 10px 0;
    }
</style>
