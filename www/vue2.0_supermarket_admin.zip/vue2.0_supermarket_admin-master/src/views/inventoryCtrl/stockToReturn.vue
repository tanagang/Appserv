<template>
    <section>
        <!--头部筛选框-->
        <el-row class="stockSelect">
            <el-form :inline="true" :model="formInline" class="demo-form-inline">
                <el-col :span="5"><div class="grid-content bg-purple">
                    <el-form-item label="商品信息">
                        <el-input v-model="formInline.user1" placeholder="请输入商品名称"></el-input>
                    </el-form-item>
                </div></el-col>
                <el-col :span="5"><div class="grid-content bg-purple-light">
                    <el-form-item label="单据编号">
                        <el-input v-model="formInline.user2" placeholder="请输入单据编号"></el-input>
                    </el-form-item>
                </div></el-col>
                <el-col :span="6" style="width: 22%;">
                    <div class="grid-content bg-purple">
                        <el-form-item label="供应商">
                            <el-select v-model="formInline.region1" placeholder="请选择供应商">
                                <el-option label="网校" value="shanghai"></el-option>
                                <el-option label="区域二" value="beijing"></el-option>
                            </el-select>
                        </el-form-item>
                    </div>
                </el-col>
                <el-col :span="2"><div class="grid-content bg-purple">
                    <el-button type="primary" icon="search">搜索</el-button>
                </div></el-col>
            </el-form>
        </el-row>

        <!--列表-->
        <el-table highlight-current-row
                  :data="stockList"
                  border
                  tooltip-effstockect="dark"
                  style="width: 100%;">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="stockIndex" label="编号" width="100">
            </el-table-column>
            <el-table-column prop="stockTime" label="业务时间" sortable>
            </el-table-column>
            <el-table-column prop="stockNum" label="单据编号" sortable>
            </el-table-column>
            <el-table-column prop="stockStockNum" label="供应商名称" sortable>
            </el-table-column>
            <el-table-column prop="stockName" label="商品名称" sortable>
            </el-table-column>
            <el-table-column prop="stockMoney" label="已付金额" sortable>
            </el-table-column>
            <el-table-column prop="stockStatus" label="入库状态" sortable>
            </el-table-column>
            <el-table-column label="操作" width="150">
                <template scope="scope">
                    <el-button size="small" @click="returnCargo()">退货</el-button>
                </template>
            </el-table-column>
        </el-table>

    </section>
</template>


<script>
    export default {
        data() {
            return {
                formInline: {
                    user1: '',
                    user2: ''
                },
                stockList:[{
                    stockIndex:'1',
                    stockTime:'2017-04-25',
                    stockNum:'523',
                    stockStockNum:'哈哈哈',
                    stockName:'我问问',
                    stockMoney:'100',
                    stockStatus:'正常'
                }, {
                    stockIndex:'1',
                    stockTime:'2017-04-25',
                    stockNum:'523',
                    stockStockNum:'哈哈哈',
                    stockName:'我问问',
                    stockMoney:'100',
                    stockStatus:'正常'
                }]
            }
        },
        methods: {
            returnCargo(){
                window.location.href = '#/returnAddCtrl'
            }
        }
    }
</script>