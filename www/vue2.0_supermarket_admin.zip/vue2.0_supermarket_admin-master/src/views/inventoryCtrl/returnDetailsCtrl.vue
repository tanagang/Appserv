<!--我是退货单详情-->
<template>
    <section>
        <el-row class="stockDetailTop">
            <el-col :span="12" ><div class="grid-content bg-purple">
                <span>供应商：<span v-model="formDetails.supplier">{{formDetails.suppName}}</span></span>
            </div></el-col>
            <el-col :span="12" class="stockDetailNum"><div class="grid-content bg-purple">
                <span>单据编号：<span v-model="formDetails.number">{{formDetails.outsCode}}</span></span>
            </div></el-col>
        </el-row>


        <!--列表-->
        <el-row class="stockDetailList">
            <el-col :span="24"><div class="grid-content bg-purple-dark">
                <el-table highlight-current-row
                          border
                          :data="returnList"
                          style="width: 100%;">
                    <el-table-column type="index" label="编号" width="100">
                    </el-table-column>
                    <el-table-column prop="barCode" label="条形码" sortable>
                    </el-table-column>
                    <el-table-column prop="goodsName" label="商品名称" sortable>
                    </el-table-column>
                    <el-table-column prop="amount" label="数量" sortable>
                    </el-table-column>
                    <el-table-column prop="price" label="单价" sortable>
                    </el-table-column>
                    <el-table-column prop="money" label="金额" sortable>
                    </el-table-column>

                </el-table>
            </div></el-col>
        </el-row>

        <el-row :gutter="20" class="stockDetailRemark">
            <el-col :span="2"><div class="grid-content bg-purple ">备注：</div></el-col>
            <el-col :span="10"><div class="grid-content bg-purple stockLayout">
                <el-input
                        type="textarea"
                        resize="none"
                        :maxlength = "100"
                        :rows="3"
                        placeholder="最多不超过100字"
                        v-model="formDetails.outsDesc">
                </el-input>
            </div></el-col>
            <el-col :span="12" ><div class="grid-content bg-purple stockLayout">
                <span>合计：</span>
                <span>{{formDetails.totalAmount}}</span>
            </div></el-col>
        </el-row>

        <div class="stockDetailBottom">
            <el-row :gutter="20">
                <el-col :span="6"><div class="grid-content bg-purple">
                    制单人：<span>{{formDetails.createdBy}}</span>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    制单时间：<span>{{formDetails.createdAt}}</span>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    结算账户： <span>{{formDetails.accountName}}</span>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    实付金额： <span>{{formDetails.refundAmount}}</span>
                </div></el-col>
            </el-row>
        </div>

        <div class="stockDetailNext">
            <el-button-group size="small">
                <el-button type="primary" icon="arrow-left">上一单</el-button>
                <el-button type="primary">下一单<i class="el-icon-arrow-right el-icon--right"></i></el-button>
            </el-button-group>
        </div>

    </section>
</template>

<script>
    export default {
        data() {
            return {
                formDetails:{},
                returnList:[]
            }
        },
        methods: {
            getDetailsData(){
                this.$http.post(
                        'http://rapapi.org/mockjsdata/18333/outStockSet/detail',
                        {
                            id:this.$route.params.id
                        }
                ).then(function(res){
                    this.formDetails = res.body.outstockInfo;
                    this.returnList = res.body.outstockGoodsDetailDto
                })
            }
        },
        mounted:function(){
            this.getDetailsData();
        }
    }
</script>

<style>
    
</style>
