<template>
    <section>
        <el-row class="stockDetailTop">
            <el-col :span="12" ><div class="grid-content bg-purple">
                <span>供应商：
                    <el-select v-model="formInline.suppId" placeholder="请选择">
                        <el-option
                                v-for="item in providerOptions"
                                :key="item.id"
                                :label="item.suppName"
                                :value="item.id">
                        </el-option>
                    </el-select>
                </span>
            </div></el-col>
            <el-col :span="12" class="stockDetailNum"><div class="grid-content bg-purple">
                <span>单据编号：<span v-model="formInline.outs_code">{{receiptCode.insCode}}</span></span>
            </div></el-col>
        </el-row>

        <!--列表-->
        <el-row class="stockDetailList">
            <el-col :span="24"><div class="grid-content bg-purple-dark">
                <el-table highlight-current-row
                          border
                          :data="stockList"
                          style="width: 100%;">
                    <el-table-column type="index" label="编号" width="100">
                    </el-table-column>

                    <el-table-column  label="条形码"  inline-template>
                            <el-date-picker prop=""  type="input" placeholder="输入条形码"  style="width:90%;">
                            </el-date-picker>
                    </el-table-column>

                    <el-table-column label="商品名称" inline-template>
                            <el-date-picker type="input" placeholder="商品名称" style="width:90%;" >
                            </el-date-picker>
                    </el-table-column>
                    <!--sortable-->
                    <el-table-column label="数量"  inline-template>
                            <el-date-picker prop="amount" type="input" placeholder="数量" style="width:90%;" >
                            </el-date-picker>
                    </el-table-column>
                    <el-table-column label="单价"  inline-template>
                        <el-date-picker prop="price" v-model="price" type="input" placeholder="单价" style="width:90%;" >
                        </el-date-picker>
                    </el-table-column>
                    <el-table-column prop="money" label="金额" sortable>
                    </el-table-column>
                    <el-table-column
                            fixed="right"
                            label="操作"
                            width="120">
                        <template scope="scope">
                            <el-button
                                    @click.native.prevent="deleteRow(scope.$index, stockList)"
                                    type="text"
                                    size="small">
                                清空
                            </el-button>
                        </template>
                    </el-table-column>

                </el-table>
            </div></el-col>

            <el-col :span="24" class="returnAdd"><div class="grid-content">
                <el-button type="info" @click="addList()">新增</el-button>
            </div></el-col>

        </el-row>

        <el-row :gutter="20" class="stockDetailRemark">
            <el-col :span="2"><div class="grid-content bg-purple ">备注：</div></el-col>
            <el-col :span="10"><div class="grid-content bg-purple stockLayout">
                <el-input
                        type="textarea"
                        resize="none"
                        :maxlength = "100"
                        :rows="3"
                        placeholder="最多不超过100字"
                        v-model="formInline.outsDesc">
                </el-input>
            </div></el-col>
            <el-col :span="12" ><div class="grid-content bg-purple stockLayout">
                <span>合计：</span>
                <span>{{form.money}}</span>
            </div></el-col>
        </el-row>

        <div class="returnAddBottom">
            <el-row :gutter="20">
                <el-col :span="8"><div class="grid-content bg-purple">
                </div></el-col>
                <el-col :span="16"><div class="grid-content ">
                    <el-form :inline="true" class="demo-form-inline">
                        <el-form-item label="结算账户">
                            <el-select v-model="formInline.accountId" placeholder="请选择">
                                <el-option
                                        v-for="item in balanceOptions"
                                        :key="item.id"
                                        :label="item.name"
                                        :value="item.id">
                                </el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="实退金额">
                            <el-input v-model="formInline.refundAmount" placeholder="请输入金额"></el-input>
                        </el-form-item>
                    </el-form>
                </div></el-col>


            </el-row>
        </div>

        <div class="returnBtn">
            <el-button type="info">保存</el-button>
            <el-button type="info" @click="cancel()">取消</el-button>
        </div>
    </section>
</template>

<script>
    export default {
        data() {
            return {
                //下拉框模拟数据
                providerOptions: [],
                balanceOptions:[],
                //需要传给后台的数据
                formInline: {
                    refundAmount:'',
                    suppId: '',
                    outsDesc: '',
                    accountId:''
                },
                //需要从后台拿到的数据
                form:{
                    money:'￥200'
                },
                receiptCode:{
                    insCode:''
                },
                //stockList:[]
                //模拟列表数据
                stockList:[{
                    amount:'1',
                    goodsId:'',
                    money:'',
                    price:'10'
                },{
                    amount:'1',
                    goodsId:'',
                    money:'',
                    price:'10'
                },{
                    amount:'1',
                    goodsId:'',
                    money:'',
                    price:'10'
                },{
                    amount:'1',
                    goodsId:'',
                    money:'',
                    price:'10'
                },{
                    amount:'1',
                    goodsId:'',
                    money:'',
                    price:'10'
                },{
                    amount:'1',
                    goodsId:'',
                    money:'',
                    price:'10'
                }]
            }
        },
        methods: {
            //获取单据编号接口
            documentCode(){
                this.$http.post(
                        'http://rapapi.org/mockjsdata/18333/inStockSet/getInsCode',
                        {
                            seqType:'03'
                        }
                )
                        .then(function(rep){
                            if(rep.status == 200){
                                this.receiptCode = rep.body
                            }
                        })
            },
            //供应商（下拉框）
            supplierSelect(){
                this.$http.get('http://rapapi.org/mockjsdata/18333/sysSupplierSet/select')
                        .then(function(res){
                            if(res.body.code == 200){
                                this.providerOptions = res.body.sysSupplierDto;
                            }
                        })
            },
            //结算账户（下拉框）
            balanceSelect(){
                this.$http.get('http://10.1.15.190:9005/sysAccountSet/select')
                        .then(function(res){
                            if(res.body.code == '000000'){
                                this.balanceOptions = res.body.sysAccountDto
                            }
                        })
            },
            //点击清空按钮
            deleteRow(index, rows) {
                this.stockList[index].stockIndex="";
                this.stockList[index].stockName="";
                this.stockList[index].stockMoney="";
                this.stockList[index].stockPrice = "";
                this.stockList[index].stockStockNum="";
                this.stockList[index].stockCode = ""
            },

            //点击添加按钮
            addList(){
                var index  = this.stockList.length+1;
                var obj = {
                    stockIndex:index,
                    stockName:'',
                    stockMoney:''
                }
                this.stockList.push(obj);
            },
            cancel(){
                window.location.href='#/returnCtrl'
            }
        },
        mounted:function(){
            this.supplierSelect();
            this.balanceSelect();
            this.documentCode();
        }
    }
</script>

<style>
    .returnAdd{
        padding-top: 30px;
    }
</style>