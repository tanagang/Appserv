<!--<div>我是新增进货</div>-->
<template>
    <section>
        <el-form :model="formInline" ref="formInline"  class="demo-ruleForm">
            <el-row class="stockDetailTop">
                <el-col :span="12" ><div class="grid-content bg-purple">
                    <span>供应商:</span>
                    <el-select v-model="formInline.suppId" placeholder="请选择供应商">
                        <el-option
                                v-for="item in providerOptions"
                                :key="item.id"
                                :label="item.suppName"
                                :value="item.id">
                        </el-option>
                    </el-select>

                </div></el-col>
                <el-col :span="12" class="stockDetailNum" prop="number"><div class="grid-content bg-purple">
                    <span>单据编号：<span v-model="receiptCode.insCode">{{receiptCode.insCode}}</span></span>
                </div></el-col>
            </el-row>

            <!--列表-->

            <el-row class="stockDetailList">
                <el-col :span="24"><div class="grid-content bg-purple-dark">

                    <el-table highlight-current-row
                              border
                              :data="stockList"
                              style="width: 100%;">
                        <el-table-column type="index" label="编号" width="100">
                        </el-table-column>

                        <el-table-column label="条形码"  inline-template>
                            <el-date-picker prop="stockCode"
                                            style="width:90%;"
                                            @blur="getCode($event)"
                                            type="input"
                                            placeholder="输入条形码" >
                            </el-date-picker>
                            <!--<el-input ></el-input>-->
                        </el-table-column>

                        <el-table-column  label="商品名称" inline-template>
                            <el-date-picker prop="stockName"
                                            style="width:90%;"
                                            type="input"
                                            placeholder="输入商品名称" >
                            </el-date-picker>
                        </el-table-column>
                        <el-table-column   label="数量"  inline-template>
                            <el-date-picker prop="amount"
                                            style="width:90%;"
                                            v-model="obj111.amount"
                                            type="input"
                                            placeholder="输入数量" >
                            </el-date-picker>
                        </el-table-column>
                        <el-table-column  label="单价" inline-template>
                            <el-date-picker prop="price"
                                            style="width:90%;"
                                            v-model="obj111.price"
                                            type="input"
                                            placeholder="输入单价" >
                            </el-date-picker>
                        </el-table-column>
                        <el-table-column  prop="money"
                                          v-model="obj111.money"
                                          label="金额"
                                          sortable>
                        </el-table-column>
                        <el-table-column label="操作">
                            <template scope="scope">
                                <el-button
                                        @click.native.prevent="deleteList(scope.$index)"
                                        type="text"
                                        size="small">
                                    清空
                                </el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </div></el-col>
                <el-col :span="24" class="returnAdd"><div class="grid-content">
                    <el-button type="info" @click="addStockList()">新增</el-button>
                </div></el-col>
            </el-row>

            <el-row :gutter="20" class="stockDetailRemark">
                <el-col :span="2"><div class="grid-content bg-purple ">备注：</div></el-col>
                <el-col :span="10"><div class="grid-content bg-purple stockLayout">
                    <el-input
                            id="text"
                            type="textarea"
                            resize="none"
                            :maxlength = "100"
                            :rows="3"
                            placeholder="最多不超过100字"
                            style="resize: none; overflow-y:hidden;"
                            v-model="formInline.insDesc">
                    </el-input>
                </div></el-col>
                <el-col :span="12" ><div class="grid-content bg-purple stockLayout">
                    <span>合计：</span>
                    <span>{{form.money}}</span>
                </div></el-col>
            </el-row>

            <div class="stockAddBottom">
                <el-row :gutter="20">
                    <el-form :inline="true" class="demo-form-inline">
                        <el-form-item label="结算账户">
                            <el-select v-model="formInline.accountId" placeholder="请选择供应商">
                                <el-option
                                        v-for="item in balanceOptions"
                                        :key="item.id"
                                        :label="item.name"
                                        :value="item.id">
                                </el-option>
                            </el-select>

                        </el-form-item>
                        <el-form-item label="实付金额" prop="user">
                            <el-input v-model="formInline.paidAmount" placeholder="请输入金额"></el-input>
                        </el-form-item>
                    </el-form>
                </el-row>
                <el-button type="info" @click="stockSave(formInline)">保存</el-button>
                <el-button type="info" @click="cancel()">取消</el-button>
            </div>
        </el-form>

    </section>
</template>

<script>
    export default {
        data() {
            return {
                //需要传给后台字段
                formInline: {
                    accountId:'',
                    insCode: '',
                    insDesc:'',
                    paidAmount:'',
                    suppId:'',
                    totalAmount:'',
                    //模拟联动数据
                    instockGoodsDetailDto:[]
                },
                obj111:{
                    amount:'',
                    goodsId:"",
                    money:"",
                    price:""
                },
                //供应商下拉框
                providerOptions: [],
                //后台获得模拟固定数据
                form:{
                    money:'￥200'
                },
                //单据编号
                receiptCode:{
                    insCode:''
                },
                stockList:[{
                    amount:'',
                    price:'',
                    money:''
                },{
                    amount:'',
                    price:'',
                    money:''
                },{
                    amount:'',
                    price:'',
                    money:''
                },{
                    amount:'',
                    price:'',
                    money:''
                },{
                    amount:'',
                    price:'',
                    money:''
                },{
                    amount:'',
                    price:'',
                    money:''
                }],
                balanceOptions:[]
            }
        },
        methods: {
            //条形码键盘触发事件
            getCode(event){
                console.info(event);
//                this.$http.post(
//                        'http://rapapi.org/mockjsdata/17930/goodsManage/search',
//                        {
//                            barCode:''
//                        }
//                )
            },
            //点击添加按钮
            addStockList(){
                var index  = this.stockList.length+1;
                var obj = {
                    money:''
                };
                this.stockList.push(obj);
            },
            //点击清空按钮
            deleteList(index, rows) {
//                this.formInline.instockGoodsDetailDto[index].amount="";
//                this.formInline.instockGoodsDetailDto[index].money="";
//                this.formInline.instockGoodsDetailDto[index].price = "";
//
//                this.stockList[index].amount="";
//                this.stockList[index].goodsId="";
//                this.stockList[index].money="";
//                this.stockList[index].price = "";
            },
            //点击取消
            cancel(){
                window.location.href='#/stockCtrl'
            },
            //保存
            stockSave(params){
                console.info(this.obj111);
                params.instockGoodsDetailDto.push(this.obj);
                console.info(params);
                this.$http.post(
                        'http://rapapi.org/mockjsdata/18333/inStockSet/add'
                ).then(function(res){
                    if(res.code == 200){
                        window.location.href = '#/stockCtrl'
                    }
                })
            },
            //获取单据编号接口
            documentCode(){
                this.$http.post(
                    'http://rapapi.org/mockjsdata/18333/inStockSet/getInsCode',
                    {
                        seqType:'02'
                    }
                ).then(function(rep){
                    if(rep.status == 200) {
                        this.receiptCode = rep.body
                    }
                })
            },
            //供应商（下拉框）
            supplierSelect(){
                this.$http.get('http://rapapi.org/mockjsdata/18333/sysSupplierSet/select')
                        .then(function(res){
                            if(res.status == 200) {
                                this.providerOptions = res.body.sysSupplierDto;
                            }
                        })
            },
            //结算账户（下拉框）
            balanceSelect(){
                this.$http.get('http://10.1.15.190:9005/sysAccountSet/select')
                        .then(function(res){
                            if(res.body.code == '000000') {
                                this.balanceOptions = res.body.sysAccountDto
                            }
                        })
            }
        },
        mounted:function(){
            this.documentCode();
            this.supplierSelect();
            this.balanceSelect();
        }
    }
</script>

<style>
    .stockDetailTop{
        width: 100%;
        padding: 10px 0;
    }
    .stockDetailNum{
        text-align: right;
    }
    .stockDetailList{
        min-height: 350px;
        border-bottom: 1px solid #999;
    }
    .stockLayout{
        text-align: center;
        vertical-align: middle;
    }
    .stockDetailRemark{
        padding: 20px 0px;
    }
    .stockAddBottom{
        width: 100%;
        height: 50px;
        line-height: 50px;
        text-align: right;
        padding-top: 20px;
        border-top: 1px solid #999;
    }

</style>