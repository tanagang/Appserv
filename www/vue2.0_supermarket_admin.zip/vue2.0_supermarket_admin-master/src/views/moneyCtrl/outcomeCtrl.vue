<template>
    <section>
        <el-row :gutter="20">
            <el-col :span="24">
                <el-form :inline="true">
                    <el-col>
                        <el-form-item>
                            <el-button type="info" @click="note_acountOutcome = true">记一笔支出</el-button>
                            <el-button type="info" @click="cancelBtn">作废</el-button>
                        </el-form-item>
                        <el-form-item>
                            <div style="margin-left: 150px">
                                <el-col >
                                    <span>单据编号：</span>
                                    <el-input placeholder="请输入单据编号" style="width: 200px">
                                    </el-input>
                                    <el-button type="info" icon="search">搜索</el-button>
                                </el-col>
                            </div>
                        </el-form-item>
                    </el-col>
                </el-form>
            </el-col>
        </el-row>

        <!--列表-->
        <el-table highlight-current-row :data="tableData" @selection-change="checkAll" style="width: 100%;">
            <el-table-column type="selection"  @select="checkOut" scope='scope'  width="55">

            </el-table-column>
            <el-table-column type="index" label="编号" width="100">
            </el-table-column>
            <el-table-column prop="createdAt" label="业务时间">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.createdAt }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="capoutCode" label="单据编号">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.capoutCode }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="accountType" label="账目类型">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.accountType }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="amount" label="金额/元">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.amount }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="accountType" label="收入账户">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.accountType }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="capinDesc" label="备注">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.capinDesc }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="isDelete" label="状态">
                <template scope="scope">
                    <span style="margin-left: 10px">{{  scope.row.isDelete }}</span>
                </template>
            </el-table-column>
            <el-table-column label="操作" prop="operation" width="150">
                <template scope="scope">
                    <el-button size="small" @click="detalsVue()">详情</el-button>
                </template>
            </el-table-column>
        </el-table>
        <div class="block" style="text-align: center;margin: 20px 0">
            <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page.sync="pageNum"
                    :page-size="pageSize"
                    layout="prev,pager,next,jumper"
                    :total="total">
            </el-pagination>
        </div>
        <!--记一笔收入-->
        <el-dialog title="记一笔支出" v-model="note_acountOutcome">
            <el-form ref="addData" :model="addData" :rules="rules"  label-width="90px">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="收入单号:" prop="capinCode">
                            <el-input :min="0" v-model="addData.capinCode" placeholder="请输入商品条码"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="记账账目:" prop="subjectId">
                            <el-select v-model="addData.subjectId" placeholder="请选择" style="width: 100%">
                                <el-option v-for="item in options" v-bind:key="item.label" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="记账金额:" prop="amount">
                            <el-input type="number" :min="0" v-model="addData.amount" placeholder="请输入记账金额"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="收入账户" prop="accountId">
                            <el-select v-model="addData.accountId" placeholder="请选择" style="width: 100%">
                                <el-option v-for="item in types" v-bind:key="item.label" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="备注:" prop="capinDesc">
                            <el-input type="textarea" :rows="3" placeholder="备注信息"  v-model="addData.capinDesc">
                            </el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
					<el-button @click="resetForm('addData')">取 消</el-button>
					<el-button type="primary" @click="addBtn('addData')">确 定</el-button>
				</span>
        </el-dialog>

    </section>
</template>

<script>
    export default {
        data() {
            return {
                addData:{
                    accountId:'',
                    amount:'',
                    capinCode:'',
                    capinDesc:'',
                    subjectId:''
                },
                rules:{
                    accountId:[{ required: true, message: '请选择收入账户', trigger: 'change' }],
                    amount:[{ required: true, message: '请输入金额', trigger: 'blur' }],
                    capinCode:[{ required: true, message: '请输入单号', trigger: 'blur' }],
                    capinDesc:[{ required: true, message: '请填写备注', trigger: 'change' }],
                    subjectId:[{ required: true, message: '请选择记账类型', trigger: 'change' }]
                },
                tableData:[],
                pickerOptions0: {
                    disabledDate(time) {
                        return time.getTime() < Date.now() - 8.64e7;
                    }
                },
                pickerOptions1: {
                    shortcuts: [{
                        text: '今天',
                        onClick(picker) {
                            picker.$emit('pick', new Date());
                        }
                    }, {
                        text: '昨天',
                        onClick(picker) {
                            const date = new Date();
                            date.setTime(date.getTime() - 3600 * 1000 * 24);
                            picker.$emit('pick', date);
                        }
                    }, {
                        text: '一周前',
                        onClick(picker) {
                            const date = new Date();
                            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', date);
                        }
                    }]
                },
                value1: '',
                value2: '',
                note_acountOutcome: false,
                textarea: '',
                options: [{
                    value: '1',
                    label: '收费缴纳'
                }, {
                    value: '2',
                    label: '电费缴纳'
                }, {
                    value: '3',
                    label: '煤气缴纳'
                }, {
                    value: '4',
                    label: '工资支出'
                }, {
                    value: '5',
                    label: '其他支出'
                }],
                optionOne: '',
                types: [{
                    value: '1',
                    label: '现金账户'
                }],
                pageNum:1,
                pageSize:1,
                pages:1,
                total:1
            };
        },
        methods:{
            //新增支出的取消按钮
            resetForm(formName){
                this.$refs[formName].resetFields();
                this.note_acountOutcome = false;
            },
            //新增添加按钮
            addBtn(formName){
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        var url='http://rapapi.org/mockjsdata/18333/capitalOut/add';
                        this.$http.post(
                                url,
                                {
                                    capinCode:this.addData
                                },{
                                    'headers':{
                                        'Content-Type':'x-www-form-urlencoded'
                                    }
                                }
                        ).then(function(response){
                            console.log(response)
                        })
                        this.note_acountOutcome = false;
                        this.$refs[formName].resetFields();
                    }else{
                        return false;
                }
                });
            },
            // get请求商品列表
            getRoute:function(){
                var that = this;
                that.$http({
                    method:'POST',
                    url:'http://rapapi.org/mockjsdata/18333/capitalOut/init',
                }).then(function(response){
                    if(response.body.code=="200"){
                        this.tableData = response.body.capitaOutDtos;
                    }
                })
            },
            detalsVue(){
                window.location.href='#/detailsCtrl?type=2'
            },
            handleSizeChange(val) {
                console.log(`每页 ${val} 条`);
            },
            handleCurrentChange(val) {
                console.log(`当前页: ${val}`);
            },
            cancelBtn(){
                var arr=[];
                for(var i=0;i<this.multipleSelection.length;i++){
                    arr.push(this.multipleSelection[i].capinCode);
                }
                var url='http://rapapi.org/mockjsdata/18333/capitalOut/cancel';
                this.$http.post(
                        url,
                        {
                            capinCode:arr
                        },{
                            'headers':{
                                'Content-Type':'x-www-form-urlencoded'
                            }
                        }
                ).then(function(response){
                    if(response.body.code==="200"){
                        for(var i = 0 ; i<this.tableData.length;i++){
                            if(this.tableData[i].isDelete == '作废'){
                                alert("已有失效的")
                                return false;
                            }
                            this.tableData[i].isDelete = '作废'
                        }
                    }
                })
            },
            //点击表头的全部勾选按钮
            checkAll(val){
                this.multipleSelection = val;
            },
            //点击勾选按钮
            checkOut(val){
                this.multipleSelection = val;
            },
        },
        created:function(){
            this.getRoute();
        }
    };
</script>


<style>
    .title {
        display: inline-table;
    }
</style>