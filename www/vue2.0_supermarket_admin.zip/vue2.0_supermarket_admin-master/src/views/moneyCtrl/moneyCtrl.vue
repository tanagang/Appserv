<template>
    <section>
        <router-view></router-view>
    </section>
</template>

<!--js 样式-->
<script>
    export default {
        data() {
            return {
                account_change_form: {
                    inputincome: '',
                    inputoutcome: '',
                    income: '',
                    input: '',
                    outcome: '',
                    date2: '',
                    delivery: false,
                    type: [],
                    resource: '',
                    desc: ''
                },
                info:'info',
                account_change: false,
                account_add: false,
                btType: true,
                comNum: '-1',
                activeName2: 'first',
                options: [{
                    value: '1',
                    label: '收费缴纳'
                }, {
                    value: '2',
                    label: '电费缴纳'
                }, {
                    value: '3',
                    label: '煤气缴纳'
                }, {
                    value: '4',
                    label: '工资支出'
                }, {
                    value: '5',
                    label: '其他支出'
                }],
                optionOne: '',
                types: [{
                    value: '1',
                    label: '现金账户'
                }, {
                    value: '2',
                    label: '微信账户'
                }, {
                    value: '3',
                    label: '支付宝账户'
                }, {
                    value: '4',
                    label: '银行卡账户'
                }],
                optionTwo: '',
                acountType: [{
                    value: 1,
                    label: '日常收入',
                    link: '/income'
                }, {
                    value: 2,
                    label: '日常支出',
                    link: '/outcome'
                }, {
                    value: 3,
                    label: '账户互转',
                    link: '/acount_acount'
                }]
            }
        },
        methods: {
            changeCol(str){
                var vm = this;
                vm.comNum = str;
                if (str==2){
                    this.account_change=true
                }
            }
        }
    }
</script>
<!--Page6 css样式-->
<style lang="scss" scoped>
    .account_statistics_main {
        width: 720px;
        height: 512px;
    }

    .zhzj_border {
        border: 1px solid #ccc;
    }

    .zhzj_margin {
        margin: 10px 0;
    }

    .el-select .el-input {
        width: 200px;
    }

    button span a {
        text-decoration: none;
        color: white;
    }
    .active{
        background-color:#ff4949;
        border-color: #ff4949;
    }
</style>
