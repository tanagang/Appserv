<template>
    <section>
        <el-row :gutter="20">
            <el-col :span="24">
                <el-form :inline="true">
                    <el-col>
                        <el-form-item>
                            <el-button type="info" @click="outComeCt" v-show="comeInType==2">支出列表</el-button>
                            <el-button type="info" @click="inComeCt"  v-show="comeInType==1">收入列表</el-button>
                        </el-form-item>
                        <el-form-item>
                            <div style="margin-left: 150px">
                                <el-col :offset="12">
                                    <span>商品名称：</span>
                                    <el-input placeholder="请输入商品名称" style="width: 200px">
                                    </el-input>
                                    <el-button icon="search">搜索</el-button>
                                </el-col>
                            </div>
                        </el-form-item>
                        <el-form-item>
                            <el-col :offset="12">
                            <span style="display: inline-block;margin-left: 250px">单据编号：{{publicData.capinCode}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                </el-form>
            </el-col>
        </el-row>
        <!--收入流水详情列表-->
        <el-table highlight-current-row :data="detailsData" v-show="comeInType==1" @selection-change="cancelBtn" style="width: 100%;min-height: 400px">
            <el-table-column type="selection"   scope='scope'  width="55">
            </el-table-column>
            <el-table-column type="index" label="编号" width="100">
            </el-table-column>
            <el-table-column prop="barCode" label="条形码">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.barCode }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="goodsName" label="商品名称">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.goodsName }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="amount" label="数量">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.amount }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="money" label="金额/元">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.money }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="totalAmount" label="小计">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.totalAmount }}</span>
                </template>
            </el-table-column>
            <el-table-column label="状态" prop="outStatus" width="150">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.outStatus }}</span>
                </template>
            </el-table-column>
        </el-table>
        <el-table highlight-current-row :data="detailsData" v-show="comeInType==2" @selection-change="cancelBtn" style="width: 100%;min-height: 400px">
            <el-table-column type="selection"   scope='scope'  width="55">
            </el-table-column>
            <el-table-column type="index" label="编号" width="100">
            </el-table-column>
            <el-table-column prop="barCode" label="条形码">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.barCode }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="goodsName" label="商品名称">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.goodsName }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="amount" label="数量">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.amount }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="money" label="金额/元">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.money }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="totalAmount" label="小计">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.totalAmount }}</span>
                </template>
            </el-table-column>
            <el-table-column label="状态" prop="outStatus" width="150">
                <template scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.outStatus }}</span>
                </template>
            </el-table-column>
        </el-table>
        <el-row type="flex" class="row-bg" justify="space-between" style="margin-top: 20px">
            <el-col :span="6"><span style="vertical-align:top;display: inline-block;color:#666">备注:</span>
                <el-input
                    type="textarea"
                    resize="none"
                    v-model="publicData.capinDesc"
                    :autosize="{ minRows: 2, maxRows: 4}"
                    placeholder="请输入内容"
                    style="width: 200px">
                </el-input>
            </el-col>
            <el-col :span="6" v-show="comeInType==2" style="vertical-align:top;">退款时间：2017-5-10-12:22:36<br/>退款状态：成功</el-col>
            <el-col :span="6"><span style="vertical-align:top;display: block;color:#666;font-size: 18px;">退款金额:<label style="font-size:18px">￥{{numMoney}}</label></span><el-button type="info" :plain="true" v-show="comeInType==1" @click="Immbtn" :offset="12">立即退货</el-button></el-col>
        </el-row>
        <el-row type="flex" class="row-bg" justify="space-between" style="margin-top: 20px">
            <el-col :span="6">
                <span>制单人:{{publicData.createdBy}}</span>
            </el-col>
            <el-col :span="6">
                <span>制单时间：{{publicData.createdAy}}</span>
            </el-col>
            <el-col :span="6">
                <el-button type="info"  size="small">上一单</el-button><el-button type="info"  size="small">下一单</el-button>
            </el-col>
        </el-row>
        <el-dialog title="退款支付" v-model="note_acountIncome">
            <el-form ref="form" label-width="80px">
                <span>订单编号：PSJ78909878</span>
                <hr/>
                <el-row :gutter="20" style="margin-top: 20px">
                    <el-col :offset="1"><span>当前支付金额：</span><label>￥{{numMoney}}</label></el-col>
                </el-row>
                <el-row :gutter="20" style="margin-top: 20px">
                    <el-col :offset="1"><span>支付方式： </span>现金方式</label></el-col>
                </el-row>
                <el-row :gutter="20" style="margin-top: 20px">
                    <el-col :offset="1"><span>退款方式：</span>
                       <span>现金方式</span>
                    </el-col>
                </el-row>
                <el-row :gutter="20" style="margin-top: 20px;text-align: center">
                    <el-button type="primary" @click="ImmSure">确 定</el-button>
                </el-row>
            </el-form>
        </el-dialog>
    </section>
</template>

<script>
    import util from '../../common/js/util'
    export default {
        data() {
            return {
                checkOne:[],
                numMoney:0,
                detailsData:[
                ],
                publicData:[],
                multipleSelection: [],
                scopeIndex:'',
                pickerOptions0: {
                    disabledDate(time) {
                        return time.getTime() < Date.now() - 8.64e7;
                    }
                },
                pickerOptions1: {
                    shortcuts: [{
                        text: '今天',
                        onClick(picker) {
                            picker.$emit('pick', new Date());
                        }
                    }, {
                        text: '昨天',
                        onClick(picker) {
                            const date = new Date();
                            date.setTime(date.getTime() - 3600 * 1000 * 24);
                            picker.$emit('pick', date);
                        }
                    }, {
                        text: '一周前',
                        onClick(picker) {
                            const date = new Date();
                            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', date);
                        }
                    }]
                },
                comeInType:'',
                note_acountIncome: false,
                textarea: '',
                payMoney:'',
                number:'',
            };
        },
        methods:{
            // get请求商品列表
            getRoute:function(){
                var that = this;
                that.$http({
                    method:'POST',
                    url:'http://rapapi.org/mockjsdata/18333/capitalIn/detail',
                }).then(function(response){
                    console.log(response);
                    if(response.body.code=="200"){
                        this.detailsData = response.body.capitalInGoodsDetailDtos;
                        this.publicData = response.body.capitalInDto;
                    }
                })
            },
            //分页按钮
            handleSizeChange(val) {
                console.log(`每页 ${val} 条`);
            },
            handleCurrentChange(val) {
                console.log(`当前页: ${val}`);
            },
            //获取传过来的值
            checkHref(){
                var comeInHref=location.href;
                var s=comeInHref.indexOf("=");
                this.comeInType=comeInHref.substring(s+1);
            },
            //点击确定确认退款
            ImmSure(){
                for(var i = 0 ; i<this.multipleSelection.length;i++){
                    this.multipleSelection[i].outStatus = '已退货'
                    this.note_acountIncome=false;
                }
            },
            //跳转页面
            inComeCt(){
                window.location.href='#/incomeCtrl'
            },
            outComeCt(){
                window.location.href='#/outcomeCtrl'
            },
            //按钮（立即退货）获取选项的金额
            Immbtn(){
                for(var i = 0 ; i<this.multipleSelection.length;i++){
                    if(this.multipleSelection[i].outStatus=='已退货'){
                        this.$message({
                            message: '选中的项目中已有退货！',
                            type: 'warning',
                        });
                        return false;
                    }else if(this.multipleSelection.length == 0){
                        console.log(this.multipleSelection.length);
                        alert('请选择一个退货')
                        return false;
                    }
                    this.payMoney = this.multipleSelection[i].money;
                }
                this.note_acountIncome=true;
                console.log(this.multipleSelection);
            },
            //单选按钮
            cancelBtn(val){
                this.multipleSelection=val;
                var money=0;
                if(val == 0){
                    this.numMoney=0.00
                }else{
                    for(var i = 0 ; i<val.length;i++){
                        money =money+parseInt(val[i].totalAmount);
                    }
                    this.numMoney = money;
                }
            }
        },
        mounted:function(){
            this.checkHref();
            this.getRoute();
        }
    };
</script>
<style>
    .cell{
        text-align: center;
    }
</style>