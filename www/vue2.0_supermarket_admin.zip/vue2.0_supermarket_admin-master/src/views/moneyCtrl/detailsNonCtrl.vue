<template>
    <section>
        <el-row :gutter="20">
            <el-col :span="24">
                <el-form :inline="true">
                    <el-col>
                        <el-form-item>
                            <el-button type="info" @click="outComeCt" v-show="comeInType==2">支出列表</el-button>
                            <el-button type="info" @click="inComeCt"  v-show="comeInType==1">收入列表</el-button>
                        </el-form-item>
                        <el-form-item>
                            <div style="margin-left: 150px">
                                <el-col :offset="12">
                                    <span>商品名称：</span>
                                    <el-input placeholder="请输入商品名称" style="width: 200px">
                                    </el-input>
                                    <el-button icon="search">搜索</el-button>
                                </el-col>
                            </div>
                        </el-form-item>
                        <el-form-item>
                            <el-col :offset="12">
                                <span style="display: inline-block;margin-left: 250px">单据编号：JHC78907890</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                </el-form>
            </el-col>
        </el-row>
        <hr/>
       <el-row style="margin-top: 20px">
           <el-col :span="21" style="color:#666;text-align: center;font-size: 20px;margin-top: 20px"><span>单据编号：PSJ7890789</span></el-col>
           <el-col :span="21" style="color:#666;text-align: center;font-size: 20px;margin-top: 30px"><span>账目类型：PSJ7890789</span></el-col>
           <el-col :span="21" style="color:#666;text-align: center;font-size: 20px;margin-top: 30px"><span>记账时间：PSJ7890789</span></el-col>
           <el-col :span="21" style="color:#666;text-align: center;font-size: 20px;margin-top: 30px"><span>收入金额：PSJ7890789</span></el-col>
           <el-col :span="21" style="color:#666;text-align: center;font-size: 20px;margin-top: 30px"><span>收入账户：PSJ7890789</span></el-col>
           <el-col :span="22" style="color:#666;text-align: center;font-size: 20px;margin: 30px 0px"><span style="vertical-align:top;display: inline-block;">备注:</span>
               <el-input
                       type="textarea"
                       resize="none"
                       :autosize="{ minRows: 2, maxRows: 4}"
                       placeholder="请输入内容"
                       style="width: 200px">
               </el-input>
           </el-input></el-col>
       </el-row>
        <!--列表-->
        <el-row type="flex" class="row-bg" justify="space-between" style="margin-top: 20px">
            <el-col :span="6">
                <span>制单人:系统</span>
            </el-col>
            <el-col :span="6">
                <span>制单时间：2017-4-17 12:12:12</span>
            </el-col>
            <el-col :span="6">
                <el-button type="info"  size="small">上一单</el-button><el-button type="info"  size="small">下一单</el-button>
            </el-col>
        </el-row>
    </section>
</template>

<script>
    import util from '../../common/js/util'
    export default {
        data() {
            return {
                labelPosition: 'right',
                formLabelAlign: {
                    name: '',
                    region: '',
                    type: ''
                },
                checkOne:[],
                numMoney:0,
                demoData:[
                    {
                        numberId:'1',
                        businessTime:'2017-04-25',
                        documentNumber:'PSJ78909878',
                        accountType:'消费订单',
                        money:'321.21',
                        inMoney:'现金账户',
                        remaker:'无',
                        operation:'已退货'
                    }
                ],
                multipleSelection: [],
                scopeIndex:'',
                comeInType:'',
                note_acountIncome: false,
                textarea: '',
                payMoney:'',
                number:''
            };
        },
        methods:{
            //获取传过来的值
            checkHref(){
                var comeInHref=location.href;
                var s=comeInHref.indexOf("=");
                this.comeInType=comeInHref.substring(s+1);
            },
            //跳转页面
            inComeCt(){
                window.location.href='#/incomeCtrl'
            },
            outComeCt(){
                window.location.href='#/outcomeCtrl'
            },
        },
        mounted:function(){
            this.checkHref();
        }
    };
</script>
<style>
    .cell{
        text-align: center;
    }
</style>