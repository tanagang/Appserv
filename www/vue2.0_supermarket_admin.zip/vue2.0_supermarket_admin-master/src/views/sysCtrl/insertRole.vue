<template>
    <section>
        <el-row :gutter="20">
            <el-col>
                <div class="grid-content bg-purple">
                    基本信息
                </div>
            </el-col>
            <el-col>
                <div class="grid-content bg-purple">
                    <el-form>
                        <el-row style="margin-bottom: 0">
                            <el-col :span="12">
                                <el-form-item label="角色名称：">
                                    <el-input placeholder="请输入角色名称"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="12">
                                <el-form-item label="角色描述：">
                                    <el-input placeholder="请输入角色描述"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                    </el-form>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20">
            <el-col>
            <div class="grid-content bg-purple">
                菜单权限
            </div>
            </el-col>
            <el-col :span="6">
                <div class="grid-content bg-purple">
                    一级菜单
                </div>
            </el-col>
            <el-col :span="12" :offset="6">
                <div class="grid-content bg-purple">
                    二级菜单
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="height: 50px">
            <el-col :span="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox v-model="Pchecked">商品管理</el-checkbox>
                    </template>
                </div>
            </el-col>
            <el-col :span="12" :offset="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox-group v-model="PcheckList">
                            <el-checkbox label="新增商品"></el-checkbox>
                            <el-checkbox label="查看详情"></el-checkbox>
                            <el-checkbox label="导入商品"></el-checkbox>
                            <el-checkbox label="导出商品"></el-checkbox>
                            <el-checkbox label="删除商品"></el-checkbox>
                        </el-checkbox-group>
                    </template>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="height: 50px">
            <el-col :span="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox v-model="Ichecked">进销存管理</el-checkbox>
                    </template>
                </div>
            </el-col>
            <el-col :span="12" :offset="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox-group v-model="IcheckList">
                            <el-checkbox label="进货管理"></el-checkbox>
                            <el-checkbox label="退货管理"></el-checkbox>
                        </el-checkbox-group>
                    </template>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="height: 50px">
            <el-col :span="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox v-model="Mchecked">资金管理</el-checkbox>
                    </template>
                </div>
            </el-col>
            <el-col :span="12" :offset="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox-group v-model="McheckList">
                            <el-checkbox label="收入流水"></el-checkbox>
                            <el-checkbox label="支出流水"></el-checkbox>
                        </el-checkbox-group>
                    </template>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="height: 50px">
            <el-col :span="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox v-model="Schecked">促销管理</el-checkbox>
                    </template>
                </div>
            </el-col>
            <el-col :span="12" :offset="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox-group v-model="ScheckList">
                            <el-checkbox label="限时折扣"></el-checkbox>
                        </el-checkbox-group>
                    </template>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="height: 50px">
            <el-col :span="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox v-model="Syschecked">系统设置</el-checkbox>
                    </template>
                </div>
            </el-col>
            <el-col :span="12" :offset="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox-group v-model="SyscheckList">
                            <el-checkbox label="商品分类"></el-checkbox>
                            <el-checkbox label="科目设置"></el-checkbox>
                            <el-checkbox label="员工管理"></el-checkbox>
                        </el-checkbox-group>
                    </template>
                </div>
            </el-col>
        </el-row>
        <el-row>
            <el-col>
                <el-button type="primary">确定</el-button>
                <el-button type="danger">删除</el-button>
            </el-col>
        </el-row>
    </section>
</template>

<script>
    export default {
        data() {
            return {
                Pchecked: false,
                Ichecked: false,
                Mchecked: false,
                Schecked: false,
                Syschecked: false,
                PcheckList: [],
                IcheckList: [],
                McheckList: [],
                ScheckList: [],
                SyscheckList: []

            };
        },
        methods: {
            //获取菜单列表
            menutree: function () {
                this.$http.get('http://10.1.16.130:9005/menuSet/menuTree').then(function (response) {
                    console.log(response)
                })
            },
            //添加角色
            insertRole: function () {
                this.$http.post('http://10.1.16.130:9005/roleSet/add',{roleName:"董事长",roleDesc:"我他么就是董事长",menuIds:[]}).then(function (response) {
                    console.log(response)
                })
            },
        },
        created: function () {
//            this.menutree()
            this.insertRole()
        }
    };
</script>

<style>

</style>
