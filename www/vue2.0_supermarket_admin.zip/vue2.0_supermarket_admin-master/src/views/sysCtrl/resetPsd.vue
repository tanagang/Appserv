<template>
   <section>
       <el-row>
           <el-col :span="12">
               <div class="grid-content bg-purple">
                   <el-form>
                       <el-form-item label="原密码：  ">
                           <el-input auto-complete="off" placeholder="请输入原密码"></el-input>
                       </el-form-item>
                       <el-form-item label="新密码：  ">
                           <el-input auto-complete="off" placeholder="请输入新密码"></el-input>
                       </el-form-item>
                       <el-form-item label="确认密码：  ">
                           <el-input auto-complete="off" placeholder="请确认新密码"></el-input>
                       </el-form-item>
                       <el-form-item label=" ">
                           <el-button type="primary">确定</el-button>
                       </el-form-item>
                   </el-form>
               </div>
           </el-col>
           <el-col :span="12">
               <div class="grid-content bg-purple-light">

               </div>
           </el-col>
       </el-row>
   </section>
</template>

<script>

</script>

<style>
    .el-input{
        width: inherit;
    }

</style>