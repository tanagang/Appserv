<template>
    <section>
        <el-button type="primary" style="margin-bottom: 20px"><router-link to="/insertRole" style="text-decoration: none;color: inherit">添加角色</router-link></el-button>
        <el-button type="primary" style="margin-bottom: 20px">删除角色</el-button>
        <el-table :data="staffData" style="width: 100%" @selection-change="handleSelectionChange">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column type="index" width="120" label="序号">
            </el-table-column>
            <el-table-column prop="roleName" label="角色名称">
            </el-table-column>
            <el-table-column prop="roleDesc" label="角色描述">
            </el-table-column>
            <el-table-column prop="createdAt" label="创建时间">
            </el-table-column>
            <el-table-column label="操作">
                <template scope="scope">
                    <el-button size="small" @click="">编辑</el-button>
                </template>
            </el-table-column>
        </el-table>
        <!--分页-->
        <div class="block">
            <el-pagination @current-change="handleCurrentChange" :page-size="100" layout="prev, pager, next, jumper" :total="1000">
            </el-pagination>
        </div>
    </section>
</template>

<script>
    export default {
        data() {
            return {
//                radio: '1',
                staffData: [],
                dialogFormVisible: false,
                form: {
                    name: '',
                    region: '',
                    delivery: false,
                    type: [],
                    resource: '',
                    desc: ''
                },
            }
        },
        methods: {
            //查询所有角色
            selectRole: function () {
                this.$http.post('http://10.1.16.130:9005/roleSet/init',{storeId:'1',pageNum:'1'}).then(function (response) {
                    console.log(response.body.sysRoleDtos)
                    this.staffData=JSON.stringify(response.body.sysRoleDtos);
                    console.log(this.staffData)
                })
            },

            //编辑
            updateRole: function () {
                this.$http.post('http://10.1.16.130:9005/roleSet/update',{id:'51',roleName:"卫生院",roleDesc:"我是善林卫生员",menuIds:[]}).then(function (response) {
                    console.log(response)
                })
            },
            //删除
            deleteRole: function () {
                this.$http.post('http://10.1.16.130:9005/roleSet/delete',{id:'51'}).then(function (response) {
                    console.log(response)
                })
            },
            handleSelectionChange(val) {
                this.multipleSelection = val;
            },
            handleCurrentChange(val) {
                console.log(`当前页: ${val}`);
            }
        },
        mounted: function () {
            this.selectRole()
//            this.updateRole()
//            this.deleteRole()
        }
    }
</script>

<style>

    th, td {
        text-align: center !important;
    }

</style>
