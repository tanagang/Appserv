<template>
    <section>
        <el-row :gutter="20">
            <el-col :span="10" :offset="2">
                <div class="grid-content bg-purple">
                    <el-input style="width: 100%" placeholder="请输入资产编号" @change="change"></el-input>
                </div>
            </el-col>
            <el-col :span="6" :offset="1">
                <div class="grid-content bg-purple">
                    <el-select v-model="form.type" placeholder="请选择型号" style="width: 100%">
                        <el-option label="27寸式挂壁" value="27寸式挂壁"></el-option>
                        <el-option label="17寸柜式" value="17寸柜式"></el-option>
                        <el-option label="机器人1号" value="机器人1号"></el-option>
                        <el-option label="机器人2号" value="机器人2号"></el-option>
                        <el-option label="机器人3号" value="机器人3号"></el-option>
                    </el-select>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="margin-top: 20px">
            <el-col :span="10" :offset="2">
                <div class="grid-content bg-purple">
                    <el-input placeholder="请输入资产编号" style="width: 100%"></el-input>
                </div>
            </el-col>
            <el-col :span="6" :offset="1">
                <div class="grid-content bg-purple">
                    <el-select v-model="form2.type" placeholder="请选择型号" style="width: 100%">
                        <el-option label="27寸式挂壁" value="27寸式挂壁"></el-option>
                        <el-option label="17寸柜式" value="17寸柜式"></el-option>
                        <el-option label="机器人1号" value="机器人1号"></el-option>
                        <el-option label="机器人2号" value="机器人2号"></el-option>
                        <el-option label="机器人3号" value="机器人3号"></el-option>
                    </el-select>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="margin-top: 20px">
            <el-col :span="10" :offset="2">
                <div class="grid-content bg-purple">
                    <el-input style="width: 100%" placeholder="请输入资产编号"></el-input>
                </div>
            </el-col>
            <el-col :span="6" :offset="1">
                <div class="grid-content bg-purple">
                    <el-select v-model="form3.type" placeholder="请选择型号" style="width: 100%">
                        <el-option label="27寸式挂壁" value="27寸式挂壁"></el-option>
                        <el-option label="17寸柜式" value="17寸柜式"></el-option>
                        <el-option label="机器人1号" value="机器人1号"></el-option>
                        <el-option label="机器人2号" value="机器人2号"></el-option>
                        <el-option label="机器人3号" value="机器人3号"></el-option>
                    </el-select>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="margin-top: 20px">
            <el-col :span="2" :offset="1">
                <div class="grid-content bg-purple">
                    门店地址：
                </div>
            </el-col>
            <el-col :span="20" :offset="1">
                <div class="grid-content bg-purple">
                    <div class="citiesLinkage">
                        <el-select class="provinces" placeholder="请选择">
                            <el-option v-for="(item,key) in provincesName" :value="key">{{item}}</el-option>
                        </el-select>
                        <el-select class="citys" placeholder="请选择">
                            <el-option v-for="(item,key) in citysName" :value="key">{{item}}</el-option>
                        </el-select>
                        <el-select class="countys" placeholder="请选择">
                            <el-option v-for="(item,key) in countysName" :value="key">{{item}}</el-option>
                        </el-select>
                    </div>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="margin-top: 20px">
            <el-col :span="2" :offset="1">
                <div class="grid-content bg-purple" style="opacity: 0">
                    门店地址：
                </div>
            </el-col>
            <el-col :span="10" :offset="1">
                <el-input placeholder="请输入具体地址"></el-input>
            </el-col>
        </el-row>
        <el-row style="margin-top: 20px">
            <el-col :span="12">
                <div class="grid-content bg-purple">
                    <span style="width: 10%"> 负责人员：</span>
                    <el-input style="width: 80%" placeholder="请输入姓名" size=""></el-input>
                </div>
            </el-col>
            <el-col :span="12">
                <div class="grid-content bg-purple">
                    <span style="width: 10%"> 手机号码：</span>
                    <el-input style="width: 80%" placeholder="请输入手机号码"></el-input>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="margin-top: 20px">
            <el-col :span="4" :offset="20">
                <el-button type="primary">保存</el-button>
            </el-col>
        </el-row>

        <el-table :data="manger" style="width: 100%;margin-top: 20px">
            <el-table-column type="index" label="编号" width="80">
            </el-table-column>
            <el-table-column prop="" label="出厂编码">
            </el-table-column>
            <el-table-column prop="" label="机器型号">
            </el-table-column>
            <el-table-column prop="" label="负责人">
            </el-table-column>
            <el-table-column prop="" label="手机号码">
            </el-table-column>
            <el-table-column label="操作">
                <template scope="scope">
                    <el-button size="small" @click="">编辑</el-button>
                    <el-button type="danger" size="small" @click="">删除</el-button>
                </template>
            </el-table-column>
        </el-table>
        <!--分页-->
    </section>
</template>


<script>

    export default {
        data () {
            return {
                form: {
                    type: ''
                },
                form2: {
                    type: ''
                },
                form3: {
                    type: ''
                },
                manger: [],
                provincesName: [],
                citysName: [],
                countysName: [],
                StoreInfoData: JSON.stringify({
                    storeInfo: {
                            chargeName: "曹明亮",
                            cityId: "130100",
                            mobilePhone: "15026616583",
                            provinceId: "130000",
                            regionId: "131100",
                            storeAddress: "广兰路"
                        },
                    storeMachine: [
                        {
                            assetCode: "1",
                            machineId: "6"
                        }
                    ]
                }),
                updateInfoData: JSON.stringify({
                    storeInfo: {
                        id:"40",
                        chargeName: "曹明亮",
                        cityId: "130100",
                        mobilePhone: "15026616583",
                        provinceId: "130000",
                        regionId: "131100",
                        storeAddress: "广兰路"
                    },
                    storeMachine: [
                        {
                            assetCode: "188888",
                            id: "10"
                        }
                    ]
                })

            }
        },
        methods: {
            change: function () {
              alert(1)
            },
            //查询机器设备信息
            machineInfo: function () {
                this.$http.get('http://192.16.2.195:9005/machineInfo').then(function (response) {
                    console.log(response)
                })
            },
            //查询门店下的机器信息
            storeMachineInfo: function () {
                this.$http.post('http://192.16.2.195:9005/storeMachineInfo', {id: '2'}, {emulateJSON: true}).then(function (response) {
                    console.log(response)
                })
            },
            //删除指定门店下的机器信息
            deleteStoreMachine: function () {
                this.$http.post('http://192.16.2.195:9005/deleteStoreMachine', {id: '2'}, {emulateJSON: true}).then(function (response) {
                    console.log(response)
                })
            },
            //新增门店以及门店绑定的机器信息
            insertStoreInfo: function () {
                this.$http.post('http://192.16.2.195:9005/insertStoreInfo', {storeMachineInfo: this.StoreInfoData}, {emulateJSON: true}).then(function (response) {
                    console.log(response)
                })
            },
            //获取所有省份城市
            getProvineInfo: function () {
                this.$http.get('http://192.16.2.195:9005/getProvineInfo').then(function (response) {
                    console.log(response)
                })
            },
            //根据省份id找到所属市
            getCityInfo: function () {
                this.$http.post('http://192.16.2.195:9005/getCityInfo', {provinceId: 130000}, {emulateJSON: true}).then(function (response) {
                    console.log(response)
                })
            },
            //根据市id找到下属区县
            getRegionInfo: function () {
                this.$http.post('http://192.16.2.195:9005/getRegionInfo', {cityId: 130100}, {emulateJSON: true}).then(function (response) {
                    console.log(response)
                })
            },
            //根据门店绑定机器id修改门店及门店绑定机器信息
            updateStoreMachineInfo: function () {
                this.$http.post('http://192.16.2.195:9005/updateStoreMachineInfo', {updateStoreMachineInfo: this.updateInfoData
                },{emulateJSON: true}).then(function (response) {
                    console.log(response)
                })
            },
            //根据用户找到门店对应的省市区
            getStoreProvCityRegiInfo: function () {
                this.$http.post('http://192.16.2.195:9005/getStoreProvCityRegiInfo', {userId: 1}, {emulateJSON: true}).then(function (response) {
                    console.log(response)
                })
            },
        },
        computed: {},
        watch: {},
        created: function () {
//            this.machineInfo()
//            this.storeMachineInfo()
//            this.deleteStoreMachine()
//            this.insertStoreInfo()
//            this.getProvineInfo()
//            this.getCityInfo()
//            this.getRegionInfo()
//            this.getStoreProvCityRegiInfo()
//            this.updateStoreMachineInfo()
        }
    }
</script>

<style>
    select {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        background-color: #fff;
        background-image: none;
        border-radius: 4px;
        border: 1px solid #bfcbd9;
        /*box-sizing: border-box;*/
        color: #1f2d3d;
        /*display: block;*/
        font-size: inherit;
        height: 36px;
        line-height: 1;
        outline: 0;
        padding: 3px 10px;
        transition: border-color .2s cubic-bezier(.645, .045, .355, 1);
    }

</style>
