<template>
    <section>
        <el-button type="primary" style="margin-bottom: 20px" @click="dialogFormVisible = true">添加科目</el-button>
        <el-button type="primary" style="margin-bottom: 20px">删除科目</el-button>
        <el-table :data="tableData" style="width: 100%">
            <el-table-column type="index" width="120" label="序号">
            </el-table-column>
            <el-table-column prop="Atype" label="账目类型">
            </el-table-column>
            <el-table-column prop="Alist" label="收支类别">
            </el-table-column>
            <el-table-column label="状态">
                <template scope="scope">
                    <input type="radio" v-bind:name="2*scope.$index+1" value="do">启用
                    <input type="radio" v-bind:name="2*scope.$index+1" value="undo">停用
                    <!--<el-radio class="radio" v-model="radio" :label="2*scope.$index+1">启用</el-radio>-->
                    <!--<el-radio class="radio" v-model="radio" :label="2*scope.$index+1">停用</el-radio>-->
                </template>
            </el-table-column>
        </el-table>
        <!--分页-->
        <div class="block">
            <el-pagination
                    :page-size="100"
                    layout="prev, pager, next, jumper"
                    :total="1000">
            </el-pagination>
        </div>
        <!--新增项目-->
        <el-dialog title="添加项目" v-model="dialogFormVisible" size="tiny">
            <el-form :model="form">
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="账户类型">
                            <el-input v-model="form.name" auto-complete="off" placeholder="请输入账户类型"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="收支类别">
                            <el-select v-model="form.region" placeholder="请选择收支类别">
                                <el-option label="收入" value="shanghai"></el-option>
                                <el-option label="支出" value="beijing"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
            </div>
        </el-dialog>
    </section>
</template>

<script>
    export default {
        data() {
            return {
                radio: '',
                tableData: [{
                    Atype: '店内销售',
                    Alist: '收入',
                    Aradio: 'radio1'
                },{
                    Atype: '利息收入',
                    Alist: '收入',
                },{
                    Atype: '投资收入',
                    Alist: '收入',
                },{
                    Atype: '账户转入',
                    Alist: '收入',
                },{
                    Atype: '其他收入',
                    Alist: '收入',
                },{
                    Atype: '账户转出',
                    Alist: '支出',
                },{
                    Atype: '水费支出',
                    Alist: '支出',
                },{
                    Atype: '工资支出',
                    Alist: '支出',
                }],
                dialogFormVisible: false,
                form: {
                    name: '',
                    region: '',
                    date1: '',
                    date2: '',
                    delivery: false,
                    type: [],
                    resource: '',
                    desc: ''
                },
            }
        },
        methods: {
            doSelect(){
                alert(1)
            }
        }
    }
</script>

<style>

    th,td {
        text-align: center !important;
    }

</style>
