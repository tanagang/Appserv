<template>
    <section>
        <el-tree :data="data" :props="defaultProps" show-checkbox node-key="id"
                 :render-content="renderContent"></el-tree>
        <!--编辑-->
        <el-dialog title="修改名称" v-model="dialogFormVisible" size="tiny">
            <el-form>
                <el-form-item>
                    <el-input auto-complete="off" v-model="message"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="editsure(this,data)">确 定</el-button>
            </div>
        </el-dialog>
    </section>
</template>

<script>
    let id = 1000;
    export default {
        data() {
            return {
                data: [{
                    id: 1,
                    label: '一级1',
                    children: [{
                        id: 4,
                        label: '二级1-1',
                        children: [{
                            id: 9,
                            label: '三级1-1-1'
                        }, {
                            id: 10,
                            label: '三级1-1-2'
                        }]
                    }]
                }, {
                    id: 2,
                    label: '一级2',
                    children: [{
                        id: 5,
                        label: '二级2-1'
                    }, {
                        id: 6,
                        label: '二级2-2'
                    }]
                }, {
                    id: 3,
                    label: '一级3',
                    children: [{
                        id: 7,
                        label: '二级3-1'
                    }, {
                        id: 8,
                        label: '二级3-2'
                    }]
                }],
                defaultProps: {
                    children: 'children',
                    label: 'label'
                },
                dialogFormVisible: false,
                message:''
            };
        },
        methods: {
            append (store, data) {
                store.append({id: id++, label: '新建文件名', children: []}, data);
            },
            remove (store, data) {
                store.remove(data);
            },
            edit (store, data){
                this.dialogFormVisible=true,
                this.message=data.label
                console.log(data.label)
            },
            editsure (store, data){
                this.dialogFormVisible = false
                   console.log(this.message)
            },
            renderContent(h, {node, data, store}) {
                return (
                <span>
                    <span>
                    <span>{node.label}</span>
                    </span>
                    <span style="float: right; margin-right: 20px">
                    <el-button type="info" size="mini" on-click={ () => this.append(store, data) }>增加</el-button>
                    <el-button size="mini" on-click={ () => this.edit(store, data) }>编辑</el-button>
                    <el-button type="danger" size="mini" on-click={ () => this.remove(store, data) }>删除</el-button>
                    </span>
                </span>
            );
            }
        }
    };
</script>

<style>
    .el-tree{
        width: 100%;
    }

</style>
