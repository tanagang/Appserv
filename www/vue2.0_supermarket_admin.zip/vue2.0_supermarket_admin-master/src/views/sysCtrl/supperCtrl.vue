<template>
    <section>
        <el-button type="primary" style="margin-bottom: 20px" @click="dialogFormVisible = true">添加供应商</el-button>
        <el-button type="primary" style="margin-bottom: 20px">删除供应商</el-button>
        <el-table :data="supperData" style="width: 100%" @selection-change="handleSelectionChange">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column type="index" width="120" label="序号">
            </el-table-column>
            <el-table-column prop="Sname" label="供应商名称">
            </el-table-column>
            <el-table-column prop="Snum" label="供应商编号">
            </el-table-column>
            <el-table-column prop="Sman" label="联系人">
            </el-table-column>
            <el-table-column prop="Stel" label="手机">
            </el-table-column>
            <el-table-column prop="index" label="状态">
                <template scope="scope">
                    <input type="radio" v-bind:name="2*scope.$index+1" value="do">启用
                    <input type="radio" v-bind:name="2*scope.$index+1" value="undo">停用
                    <!--<el-radio class="radio" v-model="radio" :label="2*scope.$index+1">启用</el-radio>-->
                    <!--<el-radio class="radio" v-model="radio" :label="2*scope.$index+1">停用</el-radio>-->
                </template>
            </el-table-column>
            <el-table-column label="操作">
                <template scope="scope">
                    <el-button size="small" @click="">编辑</el-button>
                </template>
            </el-table-column>
        </el-table>
        <!--分页-->
        <div class="block">
            <el-pagination
                    :page-size="100"
                    layout="prev, pager, next, jumper"
                    :total="1000">
            </el-pagination>
        </div>

        <!--新增项目-->
        <el-dialog title="添加供应商" v-model="dialogFormVisible">
            <el-form :model="form">
                <el-row>
                    <el-col :span="11">
                        <el-form-item label="供应商编号：" style="display: flex">
                            <el-input v-model="form.name" auto-complete="off" placeholder="请输入供应商编号"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="11" :offset="2">
                        <el-form-item label="供应商名称：" style="display: flex">
                            <el-input v-model="form.name" auto-complete="off" placeholder="请输入供应商名称"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="11">
                        <el-form-item label="联系人：" style="display: flex">
                            <el-input v-model="form.name" auto-complete="off" placeholder="请输入供应商联系人"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="11" :offset="2">
                        <el-form-item label="手机号：" style="display: flex">
                            <el-input v-model="form.name" auto-complete="off" placeholder="请输入联系人手机号"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
            </div>
        </el-dialog>
    </section>
</template>

<script>
    export default {
        data() {
            return {
//                radio: '1',
                supperData:[],
                dialogFormVisible: false,
                form: {
                    name: '',
                    region: '',
                    delivery: false,
                    type: [],
                    resource: '',
                    desc: ''
                },
            }
        },
        methods: {
            handleSelectionChange(val) {
                this.multipleSelection = val;
            }
        }
    }
</script>

<style>
        .el-form-item label{
            width: 96px;
        }
    th, td {
        text-align: center !important;
    }

</style>
