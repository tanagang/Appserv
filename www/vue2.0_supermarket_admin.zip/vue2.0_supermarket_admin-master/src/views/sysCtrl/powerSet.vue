<template>
    <section>
        <el-row :gutter="20" style="height: 50px">
            <el-col :span="6">
                <div class="grid-content bg-purple">
                    一级菜单
                </div>
            </el-col>
            <el-col :span="12" :offset="6">
                <div class="grid-content bg-purple">
                    二级菜单
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="height: 50px">
            <el-col :span="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox v-model="Pchecked">商品管理</el-checkbox>
                    </template>
                </div>
            </el-col>
            <el-col :span="12" :offset="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox-group v-model="PcheckList">
                            <el-checkbox label="新增商品"></el-checkbox>
                            <el-checkbox label="查看详情"></el-checkbox>
                            <el-checkbox label="导入商品"></el-checkbox>
                            <el-checkbox label="导出商品"></el-checkbox>
                            <el-checkbox label="删除商品"></el-checkbox>
                        </el-checkbox-group>
                    </template>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="height: 50px">
            <el-col :span="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox v-model="Ichecked">进销存管理</el-checkbox>
                    </template>
                </div>
            </el-col>
            <el-col :span="12" :offset="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox-group v-model="IcheckList">
                            <el-checkbox label="进货管理"></el-checkbox>
                            <el-checkbox label="退货管理"></el-checkbox>
                        </el-checkbox-group>
                    </template>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="height: 50px">
            <el-col :span="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox v-model="Mchecked">资金管理</el-checkbox>
                    </template>
                </div>
            </el-col>
            <el-col :span="12" :offset="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox-group v-model="McheckList">
                            <el-checkbox label="收入流水"></el-checkbox>
                            <el-checkbox label="支出流水"></el-checkbox>
                        </el-checkbox-group>
                    </template>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="height: 50px">
            <el-col :span="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox v-model="Schecked">促销管理</el-checkbox>
                    </template>
                </div>
            </el-col>
            <el-col :span="12" :offset="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox-group v-model="ScheckList">
                            <el-checkbox label="限时折扣"></el-checkbox>
                        </el-checkbox-group>
                    </template>
                </div>
            </el-col>
        </el-row>
        <el-row :gutter="20" style="height: 50px">
            <el-col :span="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox v-model="Syschecked">系统设置</el-checkbox>
                    </template>
                </div>
            </el-col>
            <el-col :span="12" :offset="6">
                <div class="grid-content bg-purple">
                    <template>
                        <el-checkbox-group v-model="SyscheckList">
                            <el-checkbox label="商品分类"></el-checkbox>
                            <el-checkbox label="科目设置"></el-checkbox>
                            <el-checkbox label="员工管理"></el-checkbox>
                        </el-checkbox-group>
                    </template>
                </div>
            </el-col>
        </el-row>
    </section>
</template>

<script>
    export default {
        data() {
            return {
                Pchecked: false,
                Ichecked: false,
                Mchecked: false,
                Schecked: false,
                Syschecked: false,
                PcheckList: [],
                IcheckList: [],
                McheckList: [],
                ScheckList: [],
                SyscheckList: []

            };
        }
    };
</script>

<style>

</style>
