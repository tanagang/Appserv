<template>
  <el-form :model="ruleForm2" :rules="rules2" ref="ruleForm2" label-position="left" label-width="0px" class="demo-ruleForm login-container">
    <div class="login">
      <h3 class="title">超市商品管理后台</h3>
    </div>
    <el-form-item prop="account" style="width: 340px;margin-left: 30px">
      <el-input type="text" v-model="ruleForm2.account" auto-complete="off" placeholder="账号" style="width: 100%"></el-input>
    </el-form-item>
    <el-form-item prop="checkPass" style="width: 340px;margin-left:30px">
      <el-input type="password" v-model="ruleForm2.checkPass" auto-complete="off" placeholder="密码" style="width: 100%"></el-input>
    </el-form-item>
    <el-form-item style="width: 340px;margin-left:30px">
      <el-row style="margin: 0">
        <el-col :span="17">
          <div class="grid-content bg-purple">
            <el-input placeholder="请输入验证码" style="width: 100%"></el-input>
          </div>
        </el-col>
        <el-col :span="6" :offset="1">
          <div class="grid-content bg-purple-light" style=" height: 36px;">
              <div id="imgCode" @click="changeCode">
                {{mycode}}
              </div>
          </div>
        </el-col>
      </el-row>
    </el-form-item>
    <el-checkbox style="margin-left: 30px" v-model="checked" checked class="remember">记住密码</el-checkbox>
    <el-form-item style="width: 340px;margin-left: 30px">
      <el-button type="primary" style="width:100%;" @click.native.prevent="handleSubmit2" :loading="logining">登录</el-button>
      <!--<el-button @click.native.prevent="handleReset2">重置</el-button>-->
    </el-form-item>
  </el-form>
</template>

<script>
  import { requestLogin } from '../api/api';
  //import NProgress from 'nprogress'
  export default {
    data() {
      return {
        logining: false,
        mycode: '111',
        ruleForm2: {
          account: '善林金融',
          checkPass: '123456',

        },

        rules2: {
          account: [
            { required: true, message: '请输入账号', trigger: 'blur' },
          ],
          checkPass: [
            { required: true, message: '请输入密码', trigger: 'blur' },
          ],
            checkcode: [
              { required: true, message: '请输入验证码', trigger: 'blur' },
          ]
        },
        checked: true,
        apiUrl : "http://rapapi.org/mockjsdata/17884/userLogin"

      };
    },
    methods: {
      handleReset2() {
        this.$refs.ruleForm2.resetFields();
      },

      handleSubmit2(ev) {
        var _this = this;
        this.$refs.ruleForm2.validate((valid) => {
          if (valid) {
            //_this.$router.replace('/table');
            this.logining = true;
            //NProgress.start();
            var loginParams = { username: this.ruleForm2.account, password: this.ruleForm2.checkPass };
            requestLogin(loginParams).then(data => {
              this.logining = false;
              //NProgress.done();
              let { msg, code, user } = data;
              if (code !== 200) {
                this.$message({
                  message: msg,
                  type: 'error'
                });
              } else {
                sessionStorage.setItem('user', JSON.stringify(user));
                this.$router.push({ path: '/' });
                  window.location.href='/'
              }
            });
          } else {
            return false;
          }
        });
      },
        changeCode(){
            var a="azxcvbnmsdfghjklqwertyuiopZXCVBNMASDFGHJKLQWERTYUIOP0123456789"
            var b=''
            var codeLength = 4
            for(var i = 0; i < codeLength; i++){
                var index=Math.floor(Math.random()*62);
                b+=a.charAt(index)+' ';
            }
            this.mycode = b
        }
    },
      mounted: function () {
        this.changeCode()
      }
  }


</script>

<style lang="scss" scoped>
  .login{
    background: url("../../static/img/logoBg.png") no-repeat;
  /*  background: url("../assets/logoBg.png") no-repeat;*/
    background-size: 100%;
    height: 140px;
    margin-bottom: 30px;
    line-height: 140px;
  }
  .login-container {
    box-shadow: 0 0px 8px 0 rgba(0, 0, 0, 0.06), 0 1px 0px 0 rgba(0, 0, 0, 0.02);
    -webkit-border-radius: 5px;
    border-radius: 5px;
    -moz-border-radius: 5px;
    background-clip: padding-box;
    margin: 150px auto;
    width: 400px;
    padding: 0 0 15px 0px;
    background: #fff;
    border: 1px solid #eaeaea;
    box-shadow: 0 0 25px #cac6c6;
  }
    .title {
      margin: 0px auto 40px auto;
      text-align: center;
      /*color: #505458;*/
      color: white;
      display: block;
      font-size: 24px;
    }
  #imgCode{
    text-align: center;
    border: 1px solid #bfcbd9;
    border-radius: 4px;
    height: 34px;
    background: url("../../static/img/code.png") no-repeat;
/*    background: url("../assets/code.png") no-repeat;*/
    background-size: 100%;
    font-weight: bold;
    font-size: 18px;
    font-style: italic;
    color: darkblue;
  }
    .remember {
      margin: 0px 0px 35px 0px;
    }
</style>
