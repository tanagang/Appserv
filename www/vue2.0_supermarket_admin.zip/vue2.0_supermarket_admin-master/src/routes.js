import Login from './views/Login.vue'
import NotFound from './views/404.vue'
import Home from './views/Home.vue'
import Main from './views/Main.vue'
// 商品管理
import productCtrl from './views/productCtrl/productCtrl.vue'
import productintro from './views/productCtrl/productIntro.vue'
import productImportCtrl from './views/productCtrl/productImportCtrl.vue'
// 进销存管理
import returnCtrl from './views/inventoryCtrl/returnCtrl.vue'
import returnDetailsCtrl from './views/inventoryCtrl/returnDetailsCtrl.vue'
import returnAddCtrl from './views/inventoryCtrl/returnAddCtrl.vue'
import returnListCtrl from './views/inventoryCtrl/returnListCtrl.vue'
import stockToReturn from './views/inventoryCtrl/stockToReturn.vue'
import stockCtrl from './views/inventoryCtrl/stockCtrl.vue'
import stockDetailsCtrl from './views/inventoryCtrl/stockDetailsCtrl.vue'
import stockAddCtrl from './views/inventoryCtrl/stockAddCtrl.vue'

import profitCtrl from './views/chartsCtrl/profitCtrl.vue'
import proSaleCtrl from './views/chartsCtrl/proSaleCtrl.vue'
import storeCtrl from './views/chartsCtrl/storeCtrl.vue'
import saleCtrl from './views/saleCtrl/saleCtrl.vue'
import memberCtrl from './views/memberCtrl/memberCtrl.vue'
import accountSet from './views/sysCtrl/accountSet.vue'
import machineBind from './views/sysCtrl/machineBind.vue'
import powerSet from './views/sysCtrl/powerSet.vue'
import productList from './views/sysCtrl/productList.vue'
import staffCtrl from './views/sysCtrl/staffCtrl.vue'
import supperCtrl from './views/sysCtrl/supperCtrl.vue'
import resetPsd from './views/sysCtrl/resetPsd.vue'
import roleCtrl from './views/sysCtrl/roleCtrl.vue'
import insertRole from './views/sysCtrl/insertRole.vue'
import moneyCtrl from './views/moneyCtrl/moneyCtrl.vue'
import incomeCtrl from './views/moneyCtrl/incomeCtrl.vue'
import outcomeCtrl from './views/moneyCtrl/outcomeCtrl.vue'
import saleAddEvent from './views/saleCtrl/saleAddEvent.vue'
import saleDetails from './views/saleCtrl/saleDetails.vue'
import detailsCtrl from './views/moneyCtrl/detailsCtrl.vue'
import detailsNonCtrl from './views/moneyCtrl/detailsNonCtrl.vue'
import productAddGoods from './views/productCtrl/productAddGoods.vue'

let routes = [
    {
        path: '/login',
        component: Login,
        name: '',
        hidden: true
    },
    {
        path: '/404',
        component: NotFound,
        name: '',
        hidden: true
    },
    {
        path: '/',
        component: Home,
        name: '商品管理',
        iconCls: 'fa fa-product-hunt',
        children: [
            {path: '/', component: Main, name: '', hidden: true},
            {path: '/productCtrl', component: productCtrl, name: '商品管理'},
            {path: '/productintro', component: productintro, name: '商品详情', hidden: true},
            {path: '/productAddGoods', component: productAddGoods, name: '新增商品'},
            {path: '/productImportCtrl', component: productImportCtrl, name: '导入商品'},
        ]
    },
    {
        path: '/',
        component: Home,
        name: '进销存管理',
        iconCls: 'fa fa-buysellads',
        children: [
            {path: '/stockCtrl', component: stockCtrl, name: '进货管理'},
            {path: '/returnCtrl', component: returnCtrl, name: '退货管理'},
            {path: '/returnDetailsCtrl/:id', component: returnDetailsCtrl, name: '退货单详情', hidden: true},
            {path: '/returnAddCtrl/:id', component: returnAddCtrl, name: '新增退货单', hidden: true},
            {path: '/returnListCtrl', component: returnListCtrl, name: '商品退货单', hidden: true},
            {path: '/stockToReturn', component: stockToReturn, name: '进货单据退货', hidden: true},
            {path: '/stockDetailsCtrl/:id', component: stockDetailsCtrl, name: '进货管理详情', hidden: true},
            {path: '/stockAddCtrl', component: stockAddCtrl, name: '新增进货单', hidden: true},        
            // {path: '/stockAddCtrl', component: stockAddCtrl, name: '新增进货单', hidden: true}ss
        ]
    },
    {
        path: '/moneyCtrl',
        component: Home,
        name: '资金管理',
        iconCls: 'fa fa-podcast',
        children: [
            {
                path: '/incomeCtrl',
                component: moneyCtrl    ,
                name: '收入流水',
                children: [
                    {
                        path: '/incomeCtrl',
                        component: incomeCtrl,
                        name: '收入流水'
                    },
                    {
                        path: '/outcomeCtrl',
                        component: outcomeCtrl,
                        name: '支出流水'
                    },
                    {
                        path: '/detailsCtrl',
                        component: detailsCtrl,
                        name: '详情页(消费订单)'
                    },
                    {
                        path:'/detailsNonCtrl',
                        component:detailsNonCtrl,
                        name:'详情页(非消费订单)'
                    }
                ]
            },
            {path: '/outcomeCtrl', component: outcomeCtrl, name: '支出流水'},
        ]
    },
    {
        path: '/',
        component: Home,
        name: '报表管理',
        iconCls: 'fa fa-bar-chart',
        children: [
            {path: '/proSaleCtrl', component: proSaleCtrl, name: '商品销售报表'},
            {path: '/storeCtrl', component: storeCtrl, name: '库存报表'},
            {path: '/profitCtrl', component: profitCtrl, name: '利润报表'}
        ]
    },
    {
        path: '/',
        component: Home,
        name: '促销管理',
        iconCls: 'fa fa-balance-scale',
        children: [
            {
                path: '/saleCtrl',
                component: saleCtrl,
                name: '限时折扣',
            },
            {
                path:'/saleAddEvent',
                component:saleAddEvent,
                name:'新增活动',
                hidden: true
            },
            {
                path:'/saleDetails',
                component:saleDetails,
                name:'商品详情',
                hidden: true
            }
        ]
    },
    {
        path: '/',
        component: Home,
        name: '系统设置',
        iconCls: 'fa fa-cogs',
        children: [
            {
                path: '/productList',
                component: productList,
                name: '商品分类'
            },
            {
                path: '/accountSet',
                component: accountSet,
                name: '科目设置'
            },
            {
                path: '/staffCtrl',
                component: staffCtrl,
                name: '员工管理'
            },
            {
                path: '/powerSet',
                component: powerSet,
                name: '权限设置'
            },
            {
                path: '/machineBind',
                component: machineBind,
                name: '机器绑定'
            },
            {
                path: '/roleCtrl',
                component: roleCtrl,
                name: '角色管理'
            },
            {
                path: '/supperCtrl',
                component: supperCtrl,
                name: '供应商管理'
            },
            {
                path: '/resetPsd',
                component: resetPsd,
                name: '修改密码'
            },
            {
                path: '/insertRole',
                component: insertRole,
                name: '角色管理'
            }
        ]
    },
    {
        path: '*',
        hidden: true,
        redirect: {path: '/404'}
    }
];

export default routes;
